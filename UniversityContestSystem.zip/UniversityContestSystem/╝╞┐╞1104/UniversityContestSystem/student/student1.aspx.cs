﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class student_Default : System.Web.UI.Page
{
    int id = 0; int studentid = 0; int sId;
    SqlConnection conn = new SqlConnection("Server = localhost; DataBase =SoftwareProject;Integrated Security = TRUE");
    /*
    protected void TableUnable()
    {
        TextBox1.Enabled = false; TextBox2.Enabled = false; TextBox5.Enabled = false;
        DropDownList1.Enabled = false; 

    }
    protected void TableAble()
    {
        TextBox1.Enabled = true; TextBox2.Enabled = true; TextBox5.Enabled = true;
        DropDownList1.Enabled = true; 

    }
   
    protected Boolean check( )
    {
        int stunumber;
        stunumber = System.Int32.Parse(TextBox1.Text);
        conn.Open();
        string sql = "select * from tb_student where stuNum = '" + stunumber + "'";
        SqlCommand comm = new SqlCommand(sql, conn);
        SqlDataReader dr = comm.ExecuteReader();
        if (dr.Read())
        {
            conn.Close();
        return  true;
        }
        else
        {
            conn.Close();
          return false;
        }
        
      
    }
     */
    //学校控件绑定
    protected void bind()
    {
        try
        {
            conn.Open();
            SqlDataAdapter dap = new SqlDataAdapter("select * from tb_school", conn);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            DropDownList1.Items.Clear();
            DropDownList1.DataSource = dt;
            DropDownList1.DataValueField = "schoolName";
            DropDownList1.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            conn.Close();
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {

            if (!IsPostBack)
            {
                
                if (Session["userId"] != null)
                    id = (int)Session["userId"];
                string sql = "select * from tb_user where uid = '" + id + "'";
                conn.Open();
                SqlCommand comm = new SqlCommand(sql, conn);
                SqlDataReader dr = comm.ExecuteReader();
                if (dr.Read())
                {
                    studentid = System.Int32.Parse(dr["fkId"].ToString());
                    dr.Close();
                }
                conn.Close();

                /*
               string sql = "select * from tb_user where uid = '" + id + "'";
                SqlCommand comm = new SqlCommand(sql, conn);  //命令
                conn.Open();
                SqlDataReader re1 = comm.ExecuteReader();
                re1.Read();
                re1.Close();
                conn.Close();
             */
                bind();

                sql = "select * from tb_student where uId = '" + studentid + "'";
                conn.Open();
                comm = new SqlCommand(sql, conn);
                SqlDataReader re = comm.ExecuteReader();
                if (re.Read())
                {
                    TextBox1.Text = re["stuNum"].ToString();
                    TextBox2.Text = re["stuName"].ToString();

                    TextBox5.Text = re["mail"].ToString();
                }
                else
                {
                    Response.Write("<script>alert('信息不完整！');</script>");
                }

                re.Close();
                conn.Close();
            }


        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            conn.Close();
        }

    }
    //提交
    protected void Button1_Click(object sender, EventArgs e)
    /**
     * 1.stuNum stuName schoolId mail
     * 2.tb_student  tb_user
     */
    {


        try
        {
            string sql = "select sId from tb_school where schoolName = '" + DropDownList1.Text + "'";
            conn.Open();
            SqlCommand comm = new SqlCommand(sql, conn);
            SqlDataReader re1 = comm.ExecuteReader();
            if (re1.Read())
            {
                sId = System.Int32.Parse(re1["sId"].ToString());
                re1.Close();
            }

            string sql1 = "update tb_student set stuNum = '" + TextBox1.Text.ToString() + "',stuName = '" + TextBox2.Text.ToString() + "',schoolId = '" + sId + "',mail = '" + TextBox5.Text.ToString() + "' where uId = '" + id + "'";
            comm = new SqlCommand(sql1, conn);
            comm.ExecuteNonQuery();
            sql = "update tb_user set  userNum = '" + TextBox1.Text.ToString() + "',userName = '" + TextBox2.Text.ToString() + "',mail = '" + TextBox5.Text.ToString() + "' where uId = '" + id + "'";
            comm = new SqlCommand(sql, conn);
            comm.ExecuteNonQuery();
            //Response.Write("<script>alert('修改成功！');</script>");
            Response.Write("<script>alert('修改成功！');window.location.href('student1.aspx');</script>");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            conn.Close();
        }



    }
    //退出
    protected void Button2_Click(object sender, EventArgs e)
    {
        //Response.Write("<script>alert('确认退出！');</script>");
        //Response.Redirect("explain.aspx");
        Response.Write("<script>alert('确认退出！');window.location.href('explain.aspx');</script>");

    }
}