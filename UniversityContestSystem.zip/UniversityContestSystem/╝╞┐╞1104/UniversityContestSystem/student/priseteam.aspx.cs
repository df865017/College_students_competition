﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class student_Default : System.Web.UI.Page
{
    string name = null;
    SqlConnection sqlcon;
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["userName"] != null)
                name = Session["userName"].ToString();
            bind();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /*
    string sqlstr = "select distinct tb_team.teamName, tb_student_contest_team.contest_name, tb_student_contest_team.stu_name,grade,prise 
    from tb_team,tb_student_contest_team,tb_school 
    where  tb_team.schoolId=tb_school.sId 
    and  tb_team.teamNum=tb_student_contest_team.id 
    and tb_student_contest_team.stu_name='" + name + "'";
      
         * */


        name = Session["userName"].ToString();
        GridViewRow src = ((GridViewRow)(((System.Web.UI.WebControls.Button)(e.CommandSource)).Parent.Parent));
        string id = GridView1.DataKeys[src.RowIndex].Value.ToString();
        //string sqlstr = "select distinct tb_team.teamName, tb_student_contest_team.contest_name, tb_student_contest_team.stu_name,grade,prise from tb_team,tb_teacher,tb_student_contest_team,tb_school where tb_team.teacherId=tb_teacher.tid and tb_team.schoolId=tb_school.sId and  tb_team.teamNum=tb_student_contest_team.id  and tb_student_contest_team.stu_name='" + name + "'";
        string sqlstr = "select distinct tb_team.teamName, tb_student_contest_team.contest_name, tb_student_contest_team.stu_name,grade,prise  from tb_team,tb_student_contest_team,tb_school where  tb_team.schoolId=tb_school.sId and  tb_team.teamNum=tb_student_contest_team.id and tb_student_contest_team.stu_name='" + name + "'";
        string teamname = null;
        string contestname = null;
        string stuname = null;
        string grade = null;
        string prise = null;
        try
        {

            sqlcon = new SqlConnection(strCon);
            sqlcon.Open();
            SqlDataReader rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            while (rd.Read())
            {
                string[] s = rd["teamName"].ToString().Split(' ');
                teamname = s[0].ToString();
                s = rd["contest_name"].ToString().Split(' ');
                contestname = s[0].ToString();
                s = rd["stu_name"].ToString().Split(' ');
                stuname = s[0].ToString();
                s = rd["grade"].ToString().Split(' ');
                grade = s[0].ToString();
                s = rd["prise"].ToString().Split(' ');
                prise = s[0].ToString();
            }
            string str = "团队名：" + teamname + "\\n" + "竞赛名：" + contestname + "\\n" + "学生名：" + stuname + "\\n" + "成绩：" + grade + "\\n" + "奖项：" + prise;
            Response.Write("<script Language='JavaScript'>alert('" + str + "')</script>");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            sqlcon.Close();
        }

    }
    //绑定gridview
    public void BindGridView(GridView gridView, DataSet ds)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //  gridView.DataSource = ds;
            //  gridView.DataBind();
            GridView1.DataSource = ds;
            GridView1.DataKeyNames = new string[] { "团队编号" };//主键
            GridView1.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columnCount = gridView.Rows[0].Cells.Count;
            gridView.Rows[0].Cells.Clear();
            gridView.Rows[0].Cells.Add(new TableCell());
            gridView.Rows[0].Cells[0].ColumnSpan = columnCount;
            gridView.Rows[0].Cells[0].Text = "没有数据";
            gridView.RowStyle.HorizontalAlign = System.Web.UI.WebControls.HorizontalAlign.Center;
        }
    }

    protected void bind()
    {
        /*
          string sqlstr = "select distinct tb_team.tId as '团队编号', tb_team.teamName as '团队名', tb_student_contest_team.contest_name as '竞赛名', tb_student_contest_team.stu_name as '组长姓名', tb_school.schoolName as '所在学校' 
         from tb_team,tb_teacher,tb_student_contest_team,tb_school 
         where tb_team.schoolId=tb_school.sId 
         and tb_team.teamNum=tb_student_contest_team.id  //teamnum==id
         and tb_student_contest_team.stu_name='" + name + "'"; 
         * */
        string sqlstr = "select distinct tb_team.tId as '团队编号', tb_team.teamName as '团队名', tb_student_contest_team.contest_name as '竞赛名', tb_student_contest_team.stu_name as '组长姓名', tb_school.schoolName as '所在学校' from tb_team,tb_teacher,tb_student_contest_team,tb_school where tb_team.schoolId=tb_school.sId  and tb_team.teamNum=tb_student_contest_team.id and tb_student_contest_team.stu_name='" + name + "'";
        try
        {
            sqlcon = new SqlConnection(strCon);
            SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
            DataSet myds = new DataSet();
            sqlcon.Open();
            myda.Fill(myds, "tb_team,tb_teacher,tb_student_contest_team,tb_school");
            //tb_team,tb_teacher,tb_student_contest_team,tb_school
            //表头为空
            BindGridView(this.GridView1, myds);
            /*
            if (myds.Tables[0].Rows.Count>0)
            {
                GridView1.DataSource = myds;
                GridView1.DataKeyNames = new string[] { "团队编号" };//主键
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script>alert('暂时没有您的成绩记录！');</script>");
            }
            */
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {

            sqlcon.Close();
        }
    }
}