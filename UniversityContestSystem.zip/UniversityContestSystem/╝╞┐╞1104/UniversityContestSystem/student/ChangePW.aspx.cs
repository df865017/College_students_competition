﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class student_Default : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
    string username;
    protected void Page_Load(object sender, EventArgs e)
    {

        int id = (int)Session["userId"];
        string sql = "select * from tb_user where uid = '" + id + "'";
        SqlCommand comm = new SqlCommand(sql, conn);  //命令
        conn.Open();
        SqlDataReader re = comm.ExecuteReader();
        if (re.Read())
        {
            username = re["userName"].ToString();
            re.Close();
            //会有延迟修改
        }
        else
        {
            Response.Write("<script>alert('登录超时，请重新登录！');</script>");
        }
        conn.Close();
        /*
                    if (Session["userName"] != null)
                    {
                        username = Session["userName"].ToString();
                    }
                    else
                    { 
            
                    }
        */
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected bool checkPW()
    {

        try
        {
            conn.Open();
            // string Sql = "select * from tb_user where userName ='" + Session["userName"] + "'and password ='" + TextBox1.Text + "'";
            string Sql = "select * from tb_user where userName ='" + username + "'and password ='" + TextBox1.Text + "'";

            SqlCommand cmd = new SqlCommand(Sql, conn);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                conn.Close();
                return true;
            }
            else
            {
                conn.Close();
                return false;
            }


        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            return false;
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Write("<script>alert('确定退出！');window.location='explain.aspx';</script>");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(TextBox1.Text) || string.IsNullOrWhiteSpace(TextBox2.Text) || string.IsNullOrWhiteSpace(TextBox3.Text))
        {
            Response.Write("<script>alert('信息不完整！');</script>");
            return;
        }
        if (!TextBox2.Text.ToString().Equals(TextBox3.Text.ToString()))
        {
            Response.Write("<script>alert('两次输入密码不一致！');</script>");
            return;
        }

        if (checkPW())
        {
            string var1; string var2; string var3;
            try
            {
                conn.Open();
                //新密码
                var1 = TextBox2.Text.ToString();
                //用户名 原密码
                // var2 = Session["userName"].ToString();
                var2 = username;
                var3 = TextBox1.Text.ToString();
                String sqlUpdate = "update tb_user set password='" + var1 + "' where userName =  '" + var2 + "' and password = '" + var3 + "' ";

                SqlCommand cmd = new SqlCommand(sqlUpdate, conn);
                int result1 = cmd.ExecuteNonQuery();

                String sqlUpdate1 = "update tb_student set password='" + var1 + "' where stuName =  '" + var2 + "' and password = '" + var3 + "' ";
                SqlCommand cmd1 = new SqlCommand(sqlUpdate1, conn);
                int result2 = cmd1.ExecuteNonQuery();

                if (result1 > 0 && result2 > 0)
                {
                    Response.Write("<script>alert('修改成功！');</script>");
                }
                else
                {
                    Response.Write("<script>alert('修改失败！');</script>");
                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                conn.Close();
            }

        }
        else
        {
            Response.Write("<script>alert('原密码错误！');</script>");

        }



    }
}