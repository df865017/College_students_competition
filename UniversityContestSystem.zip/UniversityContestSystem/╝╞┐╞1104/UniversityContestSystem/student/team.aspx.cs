﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data;
using System.Data.SqlClient;

public partial class student_Default : System.Web.UI.Page
{
    string teacher1 = ""; string teacher2 = "";
    int flag = 0;
    int fg = 1000;
    TableRow tbleRow1;
    TableRow tbleRow2;
    Button btnAdd2;
    Button btnAdd1;
    DropDownList DropDownList1; //老师学生学校
    DropDownList DropDownList2;
    DropDownList DropDownList3;
    SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GridView1.Visible = true;
            Table1False(sender, e);
            ViewState["table1rowcount"] = "1";
            ViewState["table2rowcount"] = "1";
            //隐藏
            Table2False(sender, e);
            LinkButtonFalse(sender, e);
            bind();

            //显示table
            StateFalse(sender, e);

        }

        CreateTable1Header();
        CreateTable2Header();
        for (int i = 0; i < int.Parse(ViewState["table1rowcount"].ToString()); i++)
        {
            CreateTable1Row();
        }
        for (int i = 0; i < int.Parse(ViewState["table2rowcount"].ToString()); i++)
        {
            CreateTable2Row();
        }

    }

    //绑定gridview
    public void BindGridView(GridView gridView, DataSet ds)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            GridView1.PageSize = 5;
            gridView.DataBind();

        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columnCount = gridView.Rows[0].Cells.Count;
            gridView.Rows[0].Cells.Clear();
            gridView.Rows[0].Cells.Add(new TableCell());
            gridView.Rows[0].Cells[0].ColumnSpan = columnCount;
            gridView.Rows[0].Cells[0].Text = "没有数据";
            gridView.RowStyle.HorizontalAlign = System.Web.UI.WebControls.HorizontalAlign.Center;
        }
    }
    //数据绑定
    public void bind()
    {
        string sqlstr;
        string contestkind = "团体赛";
        try
        {
            //sqlstr = "select * from tb_contest where contestKind = '" + contestkind + "' ";
            sqlstr = "select  distinct * from tb_contest, tb_contestlei,tb_school where contestKind = '" + contestkind + "' AND tb_contestlei.leiId= tb_contest.conKind AND tb_school.sId=tb_contest.schoolId";
            conn.Open();
            SqlCommand cmd = new SqlCommand(sqlstr, conn);
            cmd.ExecuteNonQuery();

            SqlDataAdapter myda = new SqlDataAdapter(sqlstr, conn);
            DataSet myds = new DataSet();
            // myda.Fill(myds, "tb_contest");
            myda.Fill(myds);
            //显示表头为空
            BindGridView(this.GridView1, myds);
            myda.Dispose();
            /*

            if (myds.Tables[0].Rows.Count == 0)
            {
                Response.Write("没有查询到数据，请重试");
            }
            else
            {
                GridView1.DataSource = myds;
                //GridView1.DataSource = myds.Tables["tb_contest"];
                // GridView1.DataKeyNames = new string[] { "conId" };
                GridView1.PageSize = 5;
                GridView1.DataBind();
                myda.Dispose();
            }

            */
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            conn.Close();
        }

    }
    //已报名
    protected int Existed()
    /*
* 0  未查询到
* 1  查询到 未审核
* 2  查询到 审核
* */
    {
        string conkind = "团体赛";

        try
        {
            conn.Open();
            string sql = string.Format("select * from tb_student_contest_team where contest_name ='" + TextBox2.Text + "' AND  stu_name = '" + Session["userName"] + "'AND contest_kind  = '" + conkind + "'");
            SqlCommand comm = new SqlCommand(sql, conn);
            SqlDataReader re = comm.ExecuteReader();
            if (re.Read())  //查询到
            {
                //查询团队名称
                TextBox1.Text = re["team_name"].ToString();
                String[] s = TextBox1.Text.Split(' ');
                TextBox1.Text = s[0].ToString();

                if (re["checkFlag_1"].ToString() == "是") // 学校审核通过，就允许通过
                {
                    conn.Close();
                    return 2;
                }

                conn.Close();
                return 1;
            }
            else
            {
                conn.Close();
                return 0;
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

        return 0;



    }
    //查询相同队名
    protected Boolean CheckSameName()
    {
        string conkind = "团体赛";

        try
        {
            conn.Open();
            string sql = string.Format("select * from tb_student_contest_team where contest_name ='" + TextBox2.Text + "' AND  team_name = '" + TextBox1.Text + "'AND contest_kind  = '" + conkind + "'");
            SqlCommand comm = new SqlCommand(sql, conn);
            SqlDataReader re = comm.ExecuteReader();
            if (re.Read())  //查询到
            {
                conn.Close();
                return true;
            }
            else
            {
                conn.Close();
                return false;
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        return false;

    }
    protected bool SearchStudent(string name)
    {
        // 团队名 竞赛名 学生名                       
        try
        {
            conn.Open();
            //string sql = string.Format("select * from tb_student_contest_team where contest_name ='" + TextBox2.Text + "'AND team_name='"+TextBox1.Text+"'");
            /*   string sql = "select * from tb_student_contest_team where stu_name ='" + name + "'AND team_name ='" + TextBox1.Text + "'AND contest_name ='" + TextBox2.Text + "'";         
              */
            string sql = "select * from tb_student_contest_team , tb_school where stu_name ='" + name + "'AND team_name ='" + TextBox1.Text + "'AND contest_name ='" + TextBox2.Text + "'AND stu_school= tb_school.sId";
            SqlCommand comm = new SqlCommand(sql, conn);
            SqlDataReader re = comm.ExecuteReader();
            if (re.Read())  //查询到
            {
                //学生学号
                TextBox5.Text = re["stu_number"].ToString();
                String[] s5 = TextBox5.Text.Split(' ');
                TextBox5.Text = s5[0].ToString();
                //TextBox5.Visible = true;
                //学生姓名
                TextBox6.Text = re["stu_name"].ToString();
                String[] s6 = TextBox6.Text.Split(' ');
                TextBox6.Text = s6[0].ToString();
                //TextBox6.Visible = true;
                //学生学校
                TextBox7.Text = re["schoolName"].ToString();
                //TextBox7.Text = re["stu_school"].ToString();
                String[] s7 = TextBox7.Text.Split(' ');
                TextBox7.Text = s7[0].ToString();
                //TextBox7.Visible = true;
                //学生电话
                TextBox8.Text = re["stu_phone"].ToString();
                String[] s8 = TextBox8.Text.Split(' ');
                TextBox8.Text = s8[0].ToString();
                //TextBox8.Visible = true;

                conn.Close();
                return true;
            }
            else
            {
                conn.Close();
                return false;
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

        return false;

    }

    protected bool SearchTeam()
    {
        try
        {
            conn.Open();
            //string sql = string.Format("select * from tb_student_contest_team where contest_name ='" + TextBox2.Text + "'AND team_name='"+TextBox1.Text+"'");
            string sql = "select * from tb_student_contest_team where contest_name ='" + TextBox2.Text + "'AND team_name ='" + TextBox1.Text + "'";
            SqlCommand comm = new SqlCommand(sql, conn);
            SqlDataReader re = comm.ExecuteReader();
            int num = 0;
            while (re.Read())  //查询到
            {
                if (num == 0)
                {
                    LinkButton1.Text = re["stu_name"].ToString();
                    String[] s = LinkButton1.Text.Split(' ');
                    LinkButton1.Text = s[0].ToString();
                    LinkButton1.Visible = true;
                    //存储教师
                    if (!string.IsNullOrWhiteSpace(re["teacher1"].ToString()))
                    {
                        LinkButton6.Text = re["teacher1"].ToString();
                        LinkButton6.Visible = true;
                    }
                    if (!string.IsNullOrWhiteSpace(re["teacher2"].ToString()))
                    {
                        LinkButton7.Text = re["teacher2"].ToString();
                        LinkButton7.Visible = true;
                    }

                }



                //显示导师信息
                /* 
                 string[] strs = re["teacher"].ToString().Split(';');
                     for (int i = 0; i < strs.Length; i++)
                     {
                         if (i == 0)
                         {
                             teacher1 = strs[i];
                             LinkButton6.Text = strs[i].ToString();
                             LinkButton6.Visible = true;
                         }
                         if (i == 1)
                         {
                             teacher2 = strs[i];
                             LinkButton7.Text = strs[i].ToString();
                             LinkButton7.Visible = true;
                         }
                     }
                                     
                 */
                if (num == 1)
                {
                    LinkButton2.Text = re["stu_name"].ToString();
                    String[] s = LinkButton2.Text.Split(' ');
                    LinkButton2.Text = s[0].ToString();
                    LinkButton2.Visible = true;
                }
                if (num == 2)
                {
                    LinkButton3.Text = re["stu_name"].ToString();
                    String[] s = LinkButton3.Text.Split(' ');
                    LinkButton3.Text = s[0].ToString();
                    LinkButton3.Visible = true;
                }
                if (num == 3)
                {
                    LinkButton4.Text = re["stu_name"].ToString();
                    String[] s = LinkButton4.Text.Split(' ');
                    LinkButton4.Text = s[0].ToString();
                    LinkButton4.Visible = true;
                }
                if (num == 4)
                {
                    LinkButton5.Text = re["stu_name"].ToString();
                    String[] s = LinkButton5.Text.Split(' ');
                    LinkButton5.Text = s[0].ToString();
                    LinkButton5.Visible = true;
                }
                num++;   //递增率
            }//while
            conn.Close();
            return true;

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        return false;


    }
    protected void Table1True(object sender, EventArgs e)
    {
        Label4.Visible = true; Label5.Visible = true; Label6.Visible = true;
        Label7.Visible = true; Label8.Visible = true; Label9.Visible = true;
        TextBox1.Visible = true; TextBox2.Visible = true; TextBox3.Visible = true; TextBox4.Visible = true;
        Table1.Visible = true; Table2.Visible = true;
        Button3.Visible = true; Button4.Visible = true; Button5.Visible = true;

    }
    protected void Table1False(object sender, EventArgs e)
    {
        Label4.Visible = false; Label5.Visible = false; Label6.Visible = false;
        Label7.Visible = false; Label8.Visible = false; Label9.Visible = false;
        TextBox1.Visible = false; TextBox2.Visible = false; TextBox3.Visible = false; TextBox4.Visible = false;
        Table1.Visible = false; Table2.Visible = false;
        Button3.Visible = false; Button4.Visible = false; Button5.Visible = false;

    }
    protected void Table2True(object sender, EventArgs e)
    {
        Label1.Visible = true; Label2.Visible = true; Label3.Visible = true; Label10.Visible = true;
        TextBox5.Visible = true; TextBox6.Visible = true; TextBox7.Visible = true; TextBox8.Visible = true;

    }
    protected void Table2False(object sender, EventArgs e)
    {
        Label1.Visible = false; Label2.Visible = false; Label3.Visible = false; Label10.Visible = false;
        TextBox5.Visible = false; TextBox6.Visible = false; TextBox7.Visible = false; TextBox8.Visible = false;
    }

    protected void StateTrue(object sender, EventArgs e)
    {
        Label11.Visible = true; Label12.Visible = true;//Lable1为判断  
        Image1.Visible = true; Image2.Visible = true;
        Image3.Visible = true; Image4.Visible = true;
    }
    protected void StateFalse(object sender, EventArgs e)
    {
        Label11.Visible = false; Label12.Visible = false;//Lable1为判断  
        Image1.Visible = false; Image2.Visible = false;
        Image3.Visible = false; Image4.Visible = false;
    }

    protected void LinkButtonTrue(object sender, EventArgs e)
    {
        //teacher
        LinkButton6.Visible = true; LinkButton7.Visible = true;
        //student
        LinkButton1.Visible = true; LinkButton2.Visible = true; LinkButton3.Visible = true; LinkButton4.Visible = true; LinkButton5.Visible = true;
    }
    protected void LinkButtonFalse(object sender, EventArgs e)
    {
        //teacher
        LinkButton6.Visible = false; LinkButton7.Visible = false;
        //student
        LinkButton1.Visible = false; LinkButton2.Visible = false; LinkButton3.Visible = false; LinkButton4.Visible = false; LinkButton5.Visible = false;
    }
    void btnDelete1_Click(object sender, EventArgs e)
    {
        if (Table1.Rows.Count <= 2)
            return;

        Table1.Rows.RemoveAt(Table1.Rows.Count - 1);
        ViewState["table1rowcount"] = int.Parse(ViewState["table1rowcount"].ToString()) - 1;
    }
    void btnDelete2_Click(object sender, EventArgs e)
    {
        if (Table2.Rows.Count <= 2)
            return;
        Table2.Rows.RemoveAt(Table2.Rows.Count - 1);
        ViewState["table2rowcount"] = int.Parse(ViewState["table2rowcount"].ToString()) - 1;
    }
    void btnAdd1_Click(object sender, EventArgs e)
    {
        if (Table1.Rows.Count >= 6)
        {
            Response.Write("<script>alert('每组组员上限为5个！');</script>");
            return;
        }

        CreateTable1Row();
        ViewState["table1rowcount"] = int.Parse(ViewState["table1rowcount"].ToString()) + 1;


    }
    void btnAdd2_Click(object sender, EventArgs e)
    {
        if (Table2.Rows.Count >= 3)
        {
            Response.Write("<script>alert('每组导师上限为2个！');</script>");
            return;
        }
        CreateTable2Row();
        ViewState["table2rowcount"] = int.Parse(ViewState["table2rowcount"].ToString()) + 1;


    }
    protected void DropDownList1bind(DropDownList DropDownList1)
    {

        conn.Open();
        SqlDataAdapter dap = new SqlDataAdapter("select * from tb_teacher", conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList1.Items.Clear();
        DropDownList1.DataSource = dt;
        DropDownList1.DataValueField = "teaName";
        DropDownList1.DataBind();
        conn.Close();
    }

    protected void DropDownList2bind(DropDownList DropDownList2)
    {

        conn.Open();
        SqlDataAdapter dap = new SqlDataAdapter("select * from tb_student", conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList2.Items.Clear();
        DropDownList2.DataSource = dt;
        DropDownList2.DataValueField = "stuName";
        DropDownList2.DataBind();
        conn.Close();
    }

    protected void DropDownList3bind(DropDownList DropDownList3)
    {

        conn.Open();
        SqlDataAdapter dap = new SqlDataAdapter("select * from tb_school", conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList3.Items.Clear();
        DropDownList3.DataSource = dt;
        DropDownList3.DataValueField = "schoolName";
        DropDownList3.DataBind();
        conn.Close();
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    //报名按钮促发事件
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Select")
        {
            GridViewRow src = ((GridViewRow)(((System.Web.UI.WebControls.Button)(e.CommandSource)).Parent.Parent)); //此得出的值是表示那行被选中的索引值 
            int index = src.RowIndex;
            //1.团队名称 
            //2.比赛项目 
            //3.负责人 
            //4.截止时间


            //参赛人
            if (Session["userName"] != null)
                TextBox3.Text = Session["userName"].ToString();
            TextBox2.Text = GridView1.Rows[index].Cells[0].Text;
            TextBox4.Text = GridView1.Rows[index].Cells[2].Text;
            DateTime date1 = System.DateTime.Now;
            DateTime date2 = Convert.ToDateTime(GridView1.Rows[index].Cells[2].Text.ToString());
            if (DateTime.Compare(date1, date2) > 0)
            {
                Response.Write("<script>alert('竞赛信息已过期！');</script>");
                return;
            }


            //判断是否已报名
            //1.已报名 切换
            //2.未报名

            if (Existed() == 1 || Existed() == 2)
            {
                // 删除 和 退出
                StateTrue(sender, e);
                GridView1.Visible = false;
                Table1True(sender, e);
                Table1.Visible = false;
                Table2.Visible = false;
                //查询团队名称  不可修改
                TextBox1.Enabled = false;
                Button3.Visible = false;
                //赋值给   HyperLink  并显示文本
                //1.个数 2.显示文本 3.点击操作 

                
                if (Existed() == 1)  //已提交
                {
                    //审核状态为wrong        right隐藏
                    //参赛状态为right     wrong隐藏  

                    Image1.Visible = false; Image4.Visible = false;
                    Button3.Visible = true;
                }
                else             //已提交 已审核
                {

                    //审核状态为rignt     wrong隐藏
                    //删除按钮隐藏
                    //参赛状态为right     wrong隐藏
                    Image2.Visible = false; Image4.Visible = false;
                    Button3.Visible = false;
                    Button5.Visible = false;
                }
                //已报名，进行信息转存；

                if (SearchTeam())
                {
                    //查询正确结果

                }
                else
                {
                    Response.Write("<script>alert('查询出错！');</script>");
                }




            }
            else   //未提交 
            {

                StateTrue(sender, e);

                GridView1.Visible = false;
                Table1True(sender, e);
                Button5.Visible = false;  //不能删除
                //审核状态为wrong     right隐藏
                //参赛状态为wrong     right隐藏
                Image1.Visible = false; Image3.Visible = false;
            }

        }
        else
        {
            //提示控件
            Response.Write("<script>alert('请核查信息！');</script>");

        }

    }
    //成员table  header
    private void CreateTable1Header()
    {
        TableHeaderRow headRow = new TableHeaderRow();
        TableHeaderCell headCell = new TableHeaderCell();
        headCell.Text = "成员编号";
        headCell.Width = 100;
        headRow.Cells.Add(headCell);

        headCell = new TableHeaderCell();
        headCell.Text = "姓名";
        headCell.Width = 100;
        headRow.Cells.Add(headCell);

        headCell = new TableHeaderCell();
        headCell.Text = "学号";
        headCell.Width = 100;
        headRow.Cells.Add(headCell);

        headCell = new TableHeaderCell();
        headCell.Text = "学校";
        headCell.Width = 100;
        headRow.Cells.Add(headCell);

        headCell = new TableHeaderCell();
        headCell.Text = "联系电话";
        headCell.Width = 100;
        headRow.Cells.Add(headCell);

        headCell = new TableHeaderCell();
        headCell.Text = "负责人(是/否)";
        headCell.Width = 100;
        headRow.Cells.Add(headCell);

        headCell = new TableHeaderCell();
        btnAdd1 = new Button();
        btnAdd1.Text = "+";                         //加号1
        btnAdd1.Click += new EventHandler(btnAdd1_Click);
        headCell.Controls.Add(btnAdd1);
        headRow.Cells.Add(headCell);

        headCell = new TableHeaderCell();
        Button btnDelete = new Button();
        btnDelete.Text = "-";                    //减号1
        btnDelete.Click += new EventHandler(btnDelete1_Click);
        headCell.Controls.Add(btnDelete);
        headRow.Cells.Add(headCell);
        Table1.Rows.Add(headRow);
    }
    //导师table header
    private void CreateTable2Header()
    {
        TableHeaderRow headRow = new TableHeaderRow();
        TableHeaderCell headCell = new TableHeaderCell();
        headCell.Text = "指导老师编号";
        headCell.Width = 150;
        headRow.Cells.Add(headCell);

        headCell = new TableHeaderCell();
        headCell.Text = "姓名";
        headCell.Width = 100;
        headRow.Cells.Add(headCell);


        headCell = new TableHeaderCell();
        btnAdd2 = new Button();
        btnAdd2.Text = "+";                         //加号2
        btnAdd2.Click += new EventHandler(btnAdd2_Click);
        headCell.Controls.Add(btnAdd2);
        headRow.Cells.Add(headCell);

        headCell = new TableHeaderCell();
        Button btnDelete = new Button();
        btnDelete.Text = "-";                    //减号2
        btnDelete.Click += new EventHandler(btnDelete2_Click);
        headCell.Controls.Add(btnDelete);
        headRow.Cells.Add(headCell);
        Table2.Rows.Add(headRow);
    }
    void CreateTable1Row()
    {

        tbleRow1 = new TableRow();
        TableCell tbleCell = new TableCell();

        tbleCell.Controls.Add(new LiteralControl(Table1.Rows.Count.ToString()));
        tbleCell.Style[HtmlTextWriterStyle.Width] = "100px";
        tbleCell.Style[HtmlTextWriterStyle.TextAlign] = "Center";
        tbleCell.Text = Table1.Rows.Count.ToString();
        tbleRow1.Cells.Add(tbleCell);
        /*
                tbleCell = new TableCell();
                TextBox txtName = new TextBox();
                txtName.ID = flag.ToString();
                flag++;
                txtName.Style[HtmlTextWriterStyle.Width] = "100px";
                tbleCell.Controls.Add(txtName);
                tbleRow1.Cells.Add(tbleCell);
        */
        tbleCell = new TableCell();
        DropDownList2 = new DropDownList();
        DropDownList2bind(DropDownList2);
        DropDownList2.ID = flag.ToString();
        flag++;
        DropDownList2.Style[HtmlTextWriterStyle.Width] = "100px";
        tbleCell.Controls.Add(DropDownList2);
        tbleRow1.Cells.Add(tbleCell);

        tbleCell = new TableCell();
        TextBox txtNum = new TextBox();
        txtNum.ID = flag.ToString();
        flag++;
        txtNum.Style[HtmlTextWriterStyle.Width] = "100px";
        tbleCell.Controls.Add(txtNum);
        tbleRow1.Cells.Add(tbleCell);

        tbleCell = new TableCell();
        DropDownList3 = new DropDownList();
        DropDownList3bind(DropDownList3);
        DropDownList3.ID = flag.ToString();
        flag++;
        DropDownList3.Style[HtmlTextWriterStyle.Width] = "100px";
        tbleCell.Controls.Add(DropDownList3);
        tbleRow1.Cells.Add(tbleCell);

        tbleCell = new TableCell();
        TextBox txtPhone = new TextBox();
        txtPhone.ID = flag.ToString();
        flag++;
        txtPhone.Style[HtmlTextWriterStyle.Width] = "100px";
        tbleCell.Controls.Add(txtPhone);
        tbleRow1.Cells.Add(tbleCell);

        tbleCell = new TableCell();
        TextBox txtPower = new TextBox();
        txtPower.ID = flag.ToString();
        flag++;
        txtPower.Style[HtmlTextWriterStyle.Width] = "100px";
        tbleCell.Controls.Add(txtPower);
        tbleRow1.Cells.Add(tbleCell);

        Table1.Rows.Add(tbleRow1);
    }
    void CreateTable2Row()
    {
        tbleRow2 = new TableRow();
        TableCell tbleCell = new TableCell();

        tbleCell.Controls.Add(new LiteralControl(Table2.Rows.Count.ToString()));
        tbleCell.Style[HtmlTextWriterStyle.Width] = "100px";
        tbleCell.Style[HtmlTextWriterStyle.TextAlign] = "Center";
        tbleCell.Text = Table2.Rows.Count.ToString();
        tbleRow2.Cells.Add(tbleCell);
        /*
        tbleCell = new TableCell();
        TextBox txtName = new TextBox();
         * 
         */
        tbleCell = new TableCell();
        DropDownList1 = new DropDownList();
        DropDownList1bind(DropDownList1);
        DropDownList1.ID = fg.ToString();
        fg++;
        DropDownList1.Style[HtmlTextWriterStyle.Width] = "100px";
        tbleCell.Controls.Add(DropDownList1);
        tbleRow2.Cells.Add(tbleCell);

        Table2.Rows.Add(tbleRow2);
    }
    //退出
    protected void Button4_Click(object sender, EventArgs e)
    {
        //切换
        Response.Write("<script>alert('确认退出！');</script>");
        Table1False(sender, e);
        GridView1.Visible = true;
        //隐藏
        Table2False(sender, e);
        LinkButtonFalse(sender, e);
        StateFalse(sender, e);

    }
    //提交
    protected void Button3_Click(object sender, EventArgs e)
    /*
     *相同团队名不允许提交
     *
     */
    {
        if (!string.IsNullOrWhiteSpace(TextBox1.Text) && !string.IsNullOrWhiteSpace(TextBox2.Text) && !string.IsNullOrWhiteSpace(TextBox3.Text) && !string.IsNullOrWhiteSpace(TextBox4.Text))
        {
            if (Existed() == 1 || Existed() == 2)
            {
                Response.Write("<script>alert('不允许重复提交！');</script>");
                return;
            }

            if (CheckSameName())
            {
                Response.Write("<script>alert('团队名已存在，请更改团队名！');</script>");
                return;
            }

            // TextBox txt0 = (TextBox)(Panel1.FindControl("0"));
            DropDownList txt0 = (DropDownList)(Panel1.FindControl("0"));
            TextBox txt1 = (TextBox)(Panel1.FindControl("1"));
            DropDownList txt2 = (DropDownList)(Panel1.FindControl("2"));
            TextBox txt3 = (TextBox)(Panel1.FindControl("3"));
            TextBox txt4 = (TextBox)(Panel1.FindControl("4"));

            //TextBox txt5 = (TextBox)(Panel1.FindControl("5"));
            DropDownList txt5 = (DropDownList)(Panel1.FindControl("5"));
            TextBox txt6 = (TextBox)(Panel1.FindControl("6"));
            DropDownList txt7 = (DropDownList)(Panel1.FindControl("7"));
            TextBox txt8 = (TextBox)(Panel1.FindControl("8"));
            TextBox txt9 = (TextBox)(Panel1.FindControl("9"));

            //TextBox txt10 = (TextBox)(Panel1.FindControl("10"));
            DropDownList txt10 = (DropDownList)(Panel1.FindControl("10"));
            TextBox txt11 = (TextBox)(Panel1.FindControl("11"));
            DropDownList txt12 = (DropDownList)(Panel1.FindControl("12"));
            TextBox txt13 = (TextBox)(Panel1.FindControl("13"));
            TextBox txt14 = (TextBox)(Panel1.FindControl("14"));

            // TextBox txt15 = (TextBox)(Panel1.FindControl("15"));
            DropDownList txt15 = (DropDownList)(Panel1.FindControl("15"));
            TextBox txt16 = (TextBox)(Panel1.FindControl("16"));
            DropDownList txt17 = (DropDownList)(Panel1.FindControl("17"));
            TextBox txt18 = (TextBox)(Panel1.FindControl("18"));
            TextBox txt19 = (TextBox)(Panel1.FindControl("19"));

            // TextBox txt20 = (TextBox)(Panel1.FindControl("20"));
            DropDownList txt20 = (DropDownList)(Panel1.FindControl("20"));
            TextBox txt21 = (TextBox)(Panel1.FindControl("21"));
            DropDownList txt22 = (DropDownList)(Panel1.FindControl("22"));
            TextBox txt23 = (TextBox)(Panel1.FindControl("23"));
            TextBox txt24 = (TextBox)(Panel1.FindControl("24"));

            DropDownList txt1000 = (DropDownList)(Panel1.FindControl("1000"));
            DropDownList txt1001 = (DropDownList)(Panel1.FindControl("1001"));

            //提交老师信息

            if (int.Parse(ViewState["table2rowcount"].ToString()) == 1)
            {
                teacher1 = txt1000.Text; teacher2 = "";
            }

            else if (int.Parse(ViewState["table2rowcount"].ToString()) == 2)
            {
                // teacher2 = txt1000.Text + ";" + txt1001.Text;
                teacher1 = txt1000.Text; teacher2 = txt1001.Text;
                if (teacher1 == teacher2)
                {
                    Response.Write("<script>alert('两个导师重名，请检查！');</script>");
                    return;
                }

            }

            else
            {
                Response.Write("<script>alert('出错，请检查！');</script>");
            }
            SqlCommand sqlcom;
            //删除team_teacher
            /*
            int id_team_teacher = 1;
            if (!string.IsNullOrWhiteSpace(txt1000.Text))
            {
                try
                {
                    conn.Open();
                    string sqlstr = "SELECT count(*) FROM tb_team_teacher ";
                    sqlcom = new SqlCommand(sqlstr, conn);
                    int count = Convert.ToInt32(sqlcom.ExecuteScalar());
                    id_team_teacher = count + 1;
                    sqlstr = "Insert into tb_team_teacher VALUES('" + id_team_teacher + "','" + TextBox2.Text + "','" + TextBox1.Text + "','团体赛','否','否','" + txt0.Text + "','" + txt1.Text + "','" + txt2.Text + "','" + txt3.Text + "','" + txt4.Text + "','" + txt1000.Text + "')";
                    sqlcom = new SqlCommand(sqlstr, conn);
                    sqlcom.ExecuteNonQuery();


                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    conn.Close();
                }

            }
            */
            /*
            if (int.Parse(ViewState["table2rowcount"].ToString()) == 2)
                if (!string.IsNullOrWhiteSpace(txt1001.Text))
                {
                    try
                    {
                        conn.Open();
                        string sqlstr = "SELECT count(*) FROM tb_team_teacher ";
                        sqlcom = new SqlCommand(sqlstr, conn);
                        int count = Convert.ToInt32(sqlcom.ExecuteScalar());
                        id_team_teacher = count + 1;
                        sqlstr = "Insert into tb_team_teacher VALUES('" + id_team_teacher + "','" + TextBox2.Text + "','" + TextBox1.Text + "','团体赛','否','否','" + txt0.Text + "','" + txt1.Text + "','" + txt2.Text + "','" + txt3.Text + "','" + txt4.Text + "','" + txt1001.Text + "')";
                        sqlcom = new SqlCommand(sqlstr, conn);
                        sqlcom.ExecuteNonQuery();

                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
             */

            //信息不完整检测


            //提交学校信息
            int id = 1;
            string sqlstr = "";
            sqlstr = "SELECT count(*) FROM tb_student_contest_team ";
            conn.Open();
            sqlcom = new SqlCommand(sqlstr, conn);
            int count1 = Convert.ToInt32(sqlcom.ExecuteScalar());
            id = count1 + 1;
            for (int i = 1; i <= int.Parse(ViewState["table1rowcount"].ToString()); i++)
            {

                     if (i == 1) sqlstr = "Insert into tb_student_contest_team VALUES('" + id + "','" + TextBox1.Text + "','" + TextBox2.Text + "','团体赛','未审核',NULL,NULL,'" + txt0.Text + "','" + txt1.Text + "', (select sId from tb_school where schoolName='" + txt2.Text + "') , '" + txt3.Text + "' ,'" + txt4.Text + "','" + teacher1 + "','" + teacher2 + "','2')";
                else if (i == 2) sqlstr = "Insert into tb_student_contest_team VALUES('" + id + "','" + TextBox1.Text + "','" + TextBox2.Text + "','团体赛','未审核',NULL,NULL,'" + txt5.Text + "','" + txt6.Text + "',(select sId from tb_school where schoolName='" + txt7.Text + "'),'" + txt8.Text + "','" + txt9.Text + "','" + teacher1 + "','" + teacher2 + "','2')";
                else if (i == 3) sqlstr = "Insert into tb_student_contest_team VALUES('" + id + "','" + TextBox1.Text + "','" + TextBox2.Text + "','团体赛','未审核',NULL,NULL,'" + txt10.Text + "','" + txt11.Text + "',(select sId from tb_school where schoolName='" + txt12.Text + "'),'" + txt13.Text + "','" + txt14.Text + "','" + teacher1 + "','" + teacher2 + "','2')";
                else if (i == 4) sqlstr = "Insert into tb_student_contest_team VALUES('" + id + "','" + TextBox1.Text + "','" + TextBox2.Text + "','团体赛','未审核',NULL,NULL,'" + txt0.Text + "','" + txt15.Text + "','" + txt16.Text + "',(select sId from tb_school where schoolName='" + txt17.Text + "'),'" + txt18.Text + "','" + teacher1 + "','" + teacher2 + "','2')";
                else if (i == 5) sqlstr = "Insert into tb_student_contest_team VALUES('" + id + "','" + TextBox1.Text + "','" + TextBox2.Text + "','团体赛','未审核',NULL,NULL,'" + txt19.Text + "','" + txt20.Text + "','" + txt21.Text + "',(select sId from tb_school where schoolName='" + txt22.Text + "'),'" + txt23.Text + "','" + teacher1 + "','" + teacher2 + "','2')";
                else
                {
                    Response.Write("<script>alert('出错，请检查！');</script>");

                }

                sqlcom = new SqlCommand(sqlstr, conn);
                sqlcom.ExecuteNonQuery();


            }
            conn.Close();
            Response.Write("<script>alert('提交成功！');</script>");
            //切换
            Table1False(sender, e);
            GridView1.Visible = true;
        }//
        else
        {
            Response.Write("<script>alert('信息不完整！');</script>");
        }



    }


    protected void Button5_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(TextBox1.Text) &&
            !string.IsNullOrWhiteSpace(TextBox2.Text) &&
            !string.IsNullOrWhiteSpace(TextBox3.Text) &&
            !string.IsNullOrWhiteSpace(TextBox4.Text) &&
            !string.IsNullOrWhiteSpace(LinkButton1.Text)
            )
        {
            Response.Write("<script>alert('确认退出竞赛！');</script>");
            //删除tb_team_teacher
            try
            {
                SqlCommand sqlcom;
                string sqlstr = "";
                conn.Open();
                sqlstr = "delete from  tb_team_teacher where contest_name ='" + TextBox2.Text + "'and team_name ='" + TextBox1.Text + "' and stu_name ='" + LinkButton1.Text + "' ";
                sqlcom = new SqlCommand(sqlstr, conn);
                sqlcom.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            //删除tb_student_contest_team
            //1.
            if (!string.IsNullOrWhiteSpace(LinkButton1.Text))
            {
                try
                {
                    SqlCommand sqlcom;
                    string sqlstr = "";
                    conn.Open();
                    sqlstr = "delete from tb_student_contest_team where contest_name ='" + TextBox2.Text + "'and team_name ='" + TextBox1.Text + "' and stu_name ='" + LinkButton1.Text + "' ";
                    sqlcom = new SqlCommand(sqlstr, conn);
                    sqlcom.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            //2.
            if (!string.IsNullOrWhiteSpace(LinkButton2.Text))
            {
                try
                {
                    SqlCommand sqlcom;
                    string sqlstr = "";
                    conn.Open();
                    sqlstr = "delete from tb_student_contest_team where contest_name ='" + TextBox2.Text + "'and team_name ='" + TextBox1.Text + "' and stu_name ='" + LinkButton2.Text + "' ";
                    sqlcom = new SqlCommand(sqlstr, conn);
                    sqlcom.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            //3.
            if (!string.IsNullOrWhiteSpace(LinkButton3.Text))
            {
                try
                {
                    SqlCommand sqlcom;
                    string sqlstr = "";
                    conn.Open();
                    sqlstr = "delete from tb_student_contest_team where contest_name ='" + TextBox2.Text + "'and team_name ='" + TextBox1.Text + "' and stu_name ='" + LinkButton3.Text + "' ";
                    sqlcom = new SqlCommand(sqlstr, conn);
                    sqlcom.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            //4.
            if (!string.IsNullOrWhiteSpace(LinkButton4.Text))
            {
                try
                {
                    SqlCommand sqlcom;
                    string sqlstr = "";
                    conn.Open();
                    sqlstr = "delete from tb_student_contest_team where contest_name ='" + TextBox2.Text + "'and team_name ='" + TextBox1.Text + "' and stu_name ='" + LinkButton4.Text + "' ";
                    sqlcom = new SqlCommand(sqlstr, conn);
                    sqlcom.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            //5.
            if (!string.IsNullOrWhiteSpace(LinkButton5.Text))
            {
                try
                {
                    SqlCommand sqlcom;
                    string sqlstr = "";
                    conn.Open();
                    sqlstr = "delete from tb_student_contest_team where contest_name ='" + TextBox2.Text + "'and team_name ='" + TextBox1.Text + "' and stu_name ='" + LinkButton5.Text + "' ";
                    sqlcom = new SqlCommand(sqlstr, conn);
                    sqlcom.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            //团队名称可修改 删除按钮消失 提交按钮显示
            TextBox1.Enabled = true;
            Button3.Visible = true;
            Button5.Visible = false;
            //切换
            Table1False(sender, e);
            GridView1.Visible = true;
            Response.Write("<script>alert('成功删除！');</script>");

        }
        else
        {
            Response.Write("<script>alert('信息不完整,无法删除！');</script>");
        }

        //隐藏
        Table2False(sender, e);
        LinkButtonFalse(sender, e);
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        string name = LinkButton1.Text.ToString();
        SearchStudent(name);
        Table2True(sender, e);
        //显示个人信息不显示状态

    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        string name = LinkButton2.Text.ToString();
        SearchStudent(name);
        Table2True(sender, e);

    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        string name = LinkButton3.Text.ToString();
        SearchStudent(name);
        Table2True(sender, e);

    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        string name = LinkButton4.Text.ToString();
        SearchStudent(name);
        Table2True(sender, e);
    }
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        string name = LinkButton5.Text.ToString();
        SearchStudent(name);
        Table2True(sender, e);
    }
    protected void LinkButton6_Click(object sender, EventArgs e)
    {

    }
    protected void LinkButton7_Click(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}