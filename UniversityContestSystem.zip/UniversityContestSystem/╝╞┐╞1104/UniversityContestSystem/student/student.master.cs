﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class student_student : System.Web.UI.MasterPage
{
    SqlConnection conn = new SqlConnection("Server = localhost; DataBase =SoftwareProject;Integrated Security = TRUE");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack && Session["userId"] != null)//判断页面是否首次被加载
        {
            int id = (int)Session["userId"];
            string sql = "select * from tb_user where uid = '" + id + "'";
            SqlCommand comm = new SqlCommand(sql, conn);  //命令
            conn.Open();
            SqlDataReader re = comm.ExecuteReader();
            if (re.Read())
            {
                Label1.Text = re["userName"].ToString();
                Session["userName"] = re["userName"].ToString();
                re.Close();
                //会有延迟修改
            }
            else
            {
                Response.Write("<script>alert('登录超时，请重新登录！');</script>");
            }
            conn.Close();

        }
    }
}
