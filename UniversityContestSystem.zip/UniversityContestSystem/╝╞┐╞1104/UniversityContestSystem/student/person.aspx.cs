﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Globalization;

public partial class student_Default : System.Web.UI.Page
{
    int id = 0;
    SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
    protected void TableFalse(object sender, EventArgs e)
    {
        Label1.Visible = false; Label2.Visible = false; Label3.Visible = false;
        Label5.Visible = false; Label6.Visible = false; Label7.Visible = false; Label8.Visible = false;
        TextBox1.Visible = false; TextBox2.Visible = false; TextBox3.Visible = false; TextBox4.Visible = false; TextBox5.Visible = false;
        DropDownList1.Visible = false; Button3.Visible = false; Button4.Visible = false; Button5.Visible = false;

    }

    protected void TableTrue(object sender, EventArgs e)
    {
        Label2.Visible = true; Label3.Visible = true;//Lable1为判断  
        Label5.Visible = true; Label6.Visible = true; Label7.Visible = true; Label8.Visible = true;
        TextBox1.Visible = true; TextBox2.Visible = true; TextBox3.Visible = true; TextBox4.Visible = true; TextBox5.Visible = true;
        DropDownList1.Visible = true; Button3.Visible = true; Button4.Visible = true; Button5.Visible = true;

    }
    protected void StateTrue(object sender, EventArgs e)
    {
        Label11.Visible = true; Label12.Visible = true;//Lable1为判断  
        Image1.Visible = true; Image2.Visible = true;
        Image3.Visible = true; Image4.Visible = true;
    }
    protected void StateFalse(object sender, EventArgs e)
    {
        Label11.Visible = false; Label12.Visible = false;//Lable1为判断  
        Image1.Visible = false; Image2.Visible = false;
        Image3.Visible = false; Image4.Visible = false;
    }

    //绑定gridview
    public void BindGridView(GridView gridView, DataSet ds)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            GridView1.PageSize = 5;
            gridView.DataBind();

        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columnCount = gridView.Rows[0].Cells.Count;
            gridView.Rows[0].Cells.Clear();
            gridView.Rows[0].Cells.Add(new TableCell());
            gridView.Rows[0].Cells[0].ColumnSpan = columnCount;
            gridView.Rows[0].Cells[0].Text = "没有数据";
            gridView.RowStyle.HorizontalAlign = System.Web.UI.WebControls.HorizontalAlign.Center;
        }
    }

    protected void bind()
    {
        //DropDownList1
        conn.Open();
        SqlDataAdapter dap = new SqlDataAdapter("select * from tb_teacher", conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList1.Items.Clear();
        DropDownList1.DataSource = dt;
        DropDownList1.DataValueField = "teaName";
        DropDownList1.DataBind();
        //参赛人
        if (Session["userName"] != null)
            TextBox4.Text = Session["userName"].ToString();
        conn.Close();



        string sqlstr;
        string contestkind = "个人赛";
        try
        {
            //sqlstr = "select conName,start,end,conKind,schoolId,contestKind from tb_contest where contestKind = '" + contestkind + "' ";
            // sqlstr = "select * from tb_contest where contestKind = '" + contestkind + "' ";
            // sqlstr = "select  distinct * from tb_contest, tb_contestlei where contestKind = '" + contestkind + "' AND tb_contestlei.leiId= tb_contest.conKind";
            sqlstr = "select  distinct * from tb_contest, tb_contestlei,tb_school where contestKind = '" + contestkind + "' AND tb_contestlei.leiId= tb_contest.conKind AND tb_school.sId=tb_contest.schoolId";
            conn.Open();
            SqlCommand cmd = new SqlCommand(sqlstr, conn);
            cmd.ExecuteNonQuery();

            SqlDataAdapter myda = new SqlDataAdapter(sqlstr, conn);
            DataSet myds = new DataSet();
            myda.Fill(myds, "tb_contest");
            // myda.Fill(myds);
            //显示表头为空
            BindGridView(this.GridView1, myds);
            myda.Dispose();
            /*
                        if (myds.Tables[0].Rows.Count == 0)
                        {
                            Response.Write("没有查询到数据，请重试");
                        }
                        else
                        {
                            //GridView1.DataSource = myds;
                            GridView1.DataSource = myds.Tables["tb_contest"];
                            // GridView1.DataKeyNames = new string[] { "conId" };
                            GridView1.PageSize = 5;
                            GridView1.DataBind();
                            myda.Dispose();
                        }
            */

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            conn.Close();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["userId"] != null)
            {
                id = (int)Session["userId"];
            }
            GridView1.Visible = true;
            TableFalse(sender, e);
            bind();
            StateFalse(sender, e);
            //切换界面需要StateFalse

        }


    }
    //protected void FindSchoolName(int schoolid)
    //{
    //    string sql = "select * from tb_stu_contest_per where contestName =" + schoolid + "";
    //    conn.Open();

    //}

    protected int checkinfo()
    /*
     * 0  未查询到
     * 1  查询到 未审核
     * 2  查询到 审核
     * */
    {
        string sql = string.Format("select checkFlag_1, checkFlag_2 from tb_stu_contest_per where contestName ='" + TextBox1.Text + "' AND studentName = '" + TextBox4.Text + "'");

        conn.Open();
        SqlCommand comm = new SqlCommand(sql, conn);
        //int i = comm.ExecuteNonQuery();
        SqlDataReader re1 = comm.ExecuteReader();

        if (re1.Read())  //查询到
        {
            if (re1["checkFlag_1"].ToString() == "是") // 学校审核通过就可以通过
            {
                conn.Close();
                return 2;
            }

            conn.Close();
            return 1;
        }
        else
        {
            conn.Close();
            return 0;
        }



    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Select")
        {
            GridViewRow src = ((GridViewRow)(((System.Web.UI.WebControls.Button)(e.CommandSource)).Parent.Parent)); //此得出的值是表示那行被选中的索引值 
            int index = src.RowIndex;
            //  string str = GridView1.Rows[index].Cells[4].Text;//获得选中行的第5列的值。
            //1.竞赛名称
            //2.参赛人
            //3.举办学校
            //4.开始时间
            //5.结束时间
            //6.指导老师
            TextBox1.Text = GridView1.Rows[index].Cells[0].Text;
            //string start1;
            TextBox2.Text = GridView1.Rows[index].Cells[1].Text.ToString();
            TextBox3.Text = GridView1.Rows[index].Cells[2].Text.ToString();
            TextBox5.Text = GridView1.Rows[index].Cells[4].Text;
            //竞赛过期

            DateTime date1 = System.DateTime.Now;
            DateTime date2 = Convert.ToDateTime(GridView1.Rows[index].Cells[2].Text.ToString());
            if (DateTime.Compare(date1, date2) > 0)
            {
                Response.Write("<script>alert('竞赛信息已过期！');</script>");
                return;
            }
            GridView1.Visible = false;
            TableTrue(sender, e);
            StateTrue(sender, e);
            if (checkinfo() == 1)   //有信息存在 删除按钮
            {
                //审核状态为wrong        right隐藏
                //参赛状态为right     wrong隐藏  

                Image1.Visible = false; Image4.Visible = false;
                Button3.Visible = true;
            }
            else if (checkinfo() == 2) //审核通过无法删除
            {
                //审核状态为rignt     wrong隐藏
                //参赛状态为right     wrong隐藏
                Image2.Visible = false; Image4.Visible = false;
                Button3.Visible = false;
            }
            else
            {
                //审核状态为wrong     right隐藏
                //参赛状态为wrong     right隐藏
                Image1.Visible = false; Image3.Visible = false;
                Button3.Visible = false; Button4.Visible = true;
            }
            if (DropDownList1.Text == "")
            {
                DropDownList1.Visible = false;
                Label1.Visible = true;
            }
            else
            {
                Label1.Visible = false;
                DropDownList1.Visible = true;
            }
            //按钮



        }
        else
        {
            //提示控件
            Response.Write("<script>alert('请核查信息！');</script>");
        }
    }//

    //删除
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(TextBox1.Text) && !string.IsNullOrWhiteSpace(TextBox2.Text) && !string.IsNullOrWhiteSpace(TextBox3.Text) && !string.IsNullOrWhiteSpace(TextBox4.Text) && !string.IsNullOrWhiteSpace(TextBox5.Text) && !string.IsNullOrWhiteSpace(DropDownList1.Text))
        // if (TextBox1.Text != "" || TextBox2.Text != "" || TextBox3.Text != "" || DropDownList1.Text != "")
        {
            //提示控件
            Response.Write("<script>alert('确认退出竞赛！');</script>");
            //竞赛名 参赛人 开始时间 截止时间
            string sql = "delete from tb_stu_contest_per where contestName ='" + TextBox1.Text + "'and studentName ='" + TextBox4.Text + "'";
            conn.Open();
            SqlCommand comm = new SqlCommand(sql, conn);
            if (!comm.Equals(""))
            {
                comm.ExecuteNonQuery();
                conn.Close();
                Response.Write("<script>alert('成功删除！');</script>");
                //切换
                TableFalse(sender, e);
                GridView1.Visible = true;
                StateFalse(sender, e);
            }
            else
            {
                conn.Close();
                Response.Write("<script>alert('不存在竞赛信息，无法删除！');</script>");
            }

        }
        else
        {

            Response.Write("<script>alert('无法删除，请核查信息！');</script>");
            //删除按钮隐藏
            Button3.Visible = false;
        }

    }

    //添加
    protected void Button4_Click(object sender, EventArgs e)
    {

        if (!string.IsNullOrWhiteSpace(TextBox1.Text) && !string.IsNullOrWhiteSpace(TextBox2.Text) && !string.IsNullOrWhiteSpace(TextBox3.Text) && !string.IsNullOrWhiteSpace(DropDownList1.Text))
        {
            if (checkinfo() == 1 || checkinfo() == 2)
            {
                Response.Write("<script>alert('不允许重复提交信息！');</script>");
                //提交按钮隐藏
            }
            else
            {

                try
                {
                     string userEmail = "";
                    if (Session["userId"] != null)
                        id = (int)Session["userId"];
                    if (Session["userEmail"] != null)
                        //userEmail = Session["userEmail"].ToString();
                        Response.Write("<script>alert('"+Session["userEmail"]+"')</script>");
                    string password = Session["password"].ToString();
                    int userNum = (int)Session["userNum"];
                    string sql = string.Format("INSERT Into tb_stu_contest_per VALUES('个人赛','" + id + "','" + TextBox1.Text + "','未审核',NULL,'" + TextBox4.Text + "','" + userNum + "','" + DropDownList1.Text + "',(select sId from tb_school where schoolName='" + TextBox5.Text + "'),'" + userEmail + "','" + password + "','" + 1 + "')");
                    conn.Open();
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    conn.Close();
                }

                Response.Write("<script>alert('提交成功，请等待审核。');window.location='person.aspx';</script>");
                TableFalse(sender, e);
                GridView1.Visible = true;
                StateFalse(sender, e);

            }

        }
        else
        {
            Response.Write("<script>alert('无法添加，请核查信息！');</script>");
        }

    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
    protected void Button5_Click(object sender, EventArgs e)
    {

        // 切换
        Response.Write("<script>alert('确认退出！');</script>");
        TableFalse(sender, e);
        GridView1.Visible = true;
        StateFalse(sender, e);
    }


}