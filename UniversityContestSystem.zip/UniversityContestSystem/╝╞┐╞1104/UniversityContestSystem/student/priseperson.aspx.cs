﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class student_Default : System.Web.UI.Page
{
    string name = null;
    SqlConnection sqlcon;
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["userName"] != null)
                name = Session["userName"].ToString();
            bind();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        /*
         string sqlstr = "select distinct contestName,studentName,grade,prise 
         from tb_stu_contest_per,tb_user_contest,tb_school 
         where tb_stu_contest_per.user_id=tb_user_contest.userId 
         and tb_stu_contest_per.school=tb_school.sId 
         and tb_stu_contest_per.studentName='" + name + "' 
         and tb_stu_contest_per.scpId= '" + id + "'";
      
         * */
        name = Session["userName"].ToString();
        GridViewRow src = ((GridViewRow)(((System.Web.UI.WebControls.Button)(e.CommandSource)).Parent.Parent));
        string id = GridView1.DataKeys[src.RowIndex].Value.ToString();
        string sqlstr = "select distinct contestName,studentName,grade,prise from tb_stu_contest_per,tb_user_contest,tb_school where tb_stu_contest_per.user_id=tb_user_contest.userId and tb_stu_contest_per.school=tb_school.sId and tb_stu_contest_per.studentName='" + name + "' and tb_stu_contest_per.scpId= '" + id + "'";
        string contestname = null;
        string studentname = null;
        string grade = null;
        string prise = null;

        try
        {

            sqlcon = new SqlConnection(strCon);
            sqlcon.Open();
            SqlDataReader rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            while (rd.Read())
            {
                contestname = rd["contestName"].ToString();
                String[] s = contestname.Split(' ');
                contestname = s[0].ToString();

                s = rd["studentName"].ToString().Split(' ');
                studentname = s[0].ToString();

                s = rd["grade"].ToString().Split(' ');
                grade = s[0].ToString();

                s = rd["prise"].ToString().Split(' ');
                prise = s[0].ToString();
            }

            string str = "竞赛名称：" + contestname + "\\n" + "学生名：" + studentname + "\\n" + "成绩：" + grade + "\\n" + "奖项：" + prise;
            // Label5.Text = contestname;
            Response.Write("<script Language='JavaScript'>alert('" + str + "')</script>");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        { sqlcon.Close(); }
    }
    //绑定gridview
    public void BindGridView(GridView gridView, DataSet ds)
    {
        if (ds.Tables[0].Rows.Count > 0)
        {
            //  gridView.DataSource = ds;
            //  gridView.DataBind();
            GridView1.DataSource = ds;
            GridView1.DataKeyNames = new string[] { "竞赛编号" };//主键
            GridView1.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columnCount = gridView.Rows[0].Cells.Count;
            gridView.Rows[0].Cells.Clear();
            gridView.Rows[0].Cells.Add(new TableCell());
            gridView.Rows[0].Cells[0].ColumnSpan = columnCount;
            gridView.Rows[0].Cells[0].Text = "没有数据";
            gridView.RowStyle.HorizontalAlign = System.Web.UI.WebControls.HorizontalAlign.Center;
        }
    }

    protected void bind()
    {
        /*
        string sqlstr = "select distinct scpId ,contestName ,studentName ,schoolName  
        from tb_stu_contest_per,tb_user_contest,tb_school
        where tb_stu_contest_per.user_id=tb_user_contest.userId 
        and tb_stu_contest_per.school=tb_school.sId 
        and tb_stu_contest_per.studentName = '" + name + "'";
        */
        try
        {

            sqlcon = new SqlConnection(strCon);
            string sqlstr = "select distinct scpId as '竞赛编号',contestName as '竞赛名称',studentName as '学生名',schoolName as '所在学校'  from tb_stu_contest_per,tb_user_contest,tb_school where tb_stu_contest_per.user_id=tb_user_contest.userId and tb_stu_contest_per.school=tb_school.sId and tb_stu_contest_per.studentName = '" + name + "'";
            SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
            DataSet myds = new DataSet();
            sqlcon.Open();
            myda.Fill(myds, "tb_stu_contest_per,tb_user_contest,tb_school");
            //显示表头为空
            BindGridView(this.GridView1, myds);
            /*
            if (myds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = myds;
                GridView1.DataKeyNames = new string[] { "竞赛编号" };//主键
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script>alert('暂时没有您的成绩记录！');</script>");
            }
             * */

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            sqlcon.Close();
        }

    }
}