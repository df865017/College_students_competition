﻿var userName, password, userType,mark,url="",e,sp,data;
$(function () {
    mark = $("#mark").attr("value");
    
    $("#butLogin").click(toLogin);

    $("#forgotpassword").click(toGetPassword);
});

function toGetPassword() {
    clearError();
    /*
    if (!(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test($("#userEmail").attr("value")))) {
        e = $("#userEmail");
        sp = document.createElement("span");
        sp.className = "error";
        sp.innerHTML = "<font color='red'> &nbsp;&nbsp;*请填写正确的邮箱地址</font>";
        e.parent().append(sp);
        e.focus();
    }
    else {*/
        if (mark == "home") {
            url = "../Controller/Log_Reg/ForgotPw/ForgotPwController.aspx";
        }
        else {//注册和激活页面
            url = "../../../Controller/Log_Reg/ForgotPw/ForgotPwController.aspx";
        }
        userName = $("#userName").attr("value");
        data = {
            "userName": userName
        };
        clearError();
        $.post(url, data, function (Result) {
            e = $("#showFail");
            sp = document.createElement("span");
            sp.className = "error";
            if (Result.getPwStatus == "SEND_PW_FAILED"){//获取密码失败
                sp.innerHTML = "<font color='red'> &nbsp;&nbsp;获取密码失败，请检查网络</font>";
            }
            else if(Result.getPwStatus == "USER_NOT_EXIST"){//用户不存在
                sp.innerHTML = "<font color='red'> &nbsp;&nbsp;用户不存在，请重新用户名</font>";
            }
            else if(Result.getPwStatus == "SEND_PW_SUCCESS"){//密码发送成功
                sp.innerHTML = "<font color='red'> &nbsp;&nbsp;密码发送成功，请去您的邮箱查看新密码</font>";
            }
            else{
                sp.innerHTML = "<font color='red'> &nbsp;&nbsp;获取密码失败</font>";
            }
            e.parent().append(sp);
        }, "json");
    //}
}


function toLogin() {
    if (checkLogin()) {
        login();
    }
}
function checkLogin() {
    userName = $("#userName").attr("value");
    password = $("#password").attr("value");
    txtValidate = $("#txtValidate").attr("value");
    userType = $('input[name="logType"]:checked').val();
    clearError();
    /*
    if (!(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(userEmail))) {
        e = $("#userEmail");
        sp = document.createElement("span");
        sp.className = "error";
        sp.innerHTML = "<font color='red'> &nbsp;&nbsp;*请填写正确的邮箱地址</font>";
        e.parent().append(sp);
        e.focus();
        return false
    }
    else*/ 
    if (password == "") {
        e = $("#password");
        sp = document.createElement("span");
        sp.className = "error";
        sp.innerHTML = "<font color='red'> &nbsp;&nbsp;*请输入密码</font>";
        e.parent().append(sp);
        e.focus();
        return false;
    }
    else if (txtValidate == "") {
        e = $("#txtValidate");
        sp = document.createElement("span");
        sp.className = "error";
        sp.innerHTML = "<font color='red'> &nbsp;&nbsp;*请输入验证码</font>";
        e.parent().append(sp);
        e.focus();
        return false
    }
    else {
        return true;
    }
}

function login() {
    if (mark == "home") {
        url = "../Controller/Log_Reg/Login/LoginController.aspx";
    }
    else {//注册和激活页面
        url = "../../../Controller/Log_Reg/Login/LoginController.aspx";
    }
    data = {
        "userName": userName,
        "password": password,
        "userType": userType,
        "txtValidate": txtValidate
    };
    $.post(url, data, function (Result) {
        e = $("#showFail");
        sp = document.createElement("span");
        sp.className = "error";
        clearError();
        if (Result.loginStatus == "LOGIN_SUCCESS") {//登录成功，跳转到persona页
            if (mark == "home") {
                if (userType == "0") {
                    //window.location = "Base_Info/admin1.aspx?id=" + Result.id;
                    window.location = "../jiaowei/home.aspx";
                }
                else if (userType == "1") {
                    window.location = "../student/explain.aspx";                  //变换修改
                }
                else if (userType == "2") {
                    window.location = "../Page/Con_Apply/teacher/teacher1.aspx";
                }
                else {
                    window.location = "../school/Home.aspx";
                }
                //window.location = "Personal.aspx?id" + Result.id;
            }
            else {
                if (userType == "0") {
                    window.location = "../jiaowei/home.aspx";
                }
                else if (userType == "1") {
                    window.location = "../student/explain.aspx";    //变换修改
                }
                else if (userType == "2") {
                    window.location = "../Page/Con_Apply/teacher/teacher1.aspx";
                }
                else {
                    window.location = "../school/abc.apsx";
                }
                //window.location = "../../Personal.aspx?id=" + Result.id;
            }
        }
        else if (Result.loginStatus == "CODE_ERROR") {
            sp.innerHTML = "<font color='red'>请填写正确的验证码</font>";
        }
        else if (Result.loginStatus == "HAS_LOGINED") {//已登录 
            sp.innerHTML = "<font color='red'>您好，您已经登录</font>";
        }
        else if (Result.loginStatus == "NOT_ACTIVED")//已注册，未激活
        {
            sp.innerHTML = "<font color='red'>您已注册，请查看您的邮箱进行激活</font>";
        }
        else {
            sp.innerHTML = "<font color='red'>用户名或密码错误，登录失败</font>";
        }
        e.parent().append(sp);
    }, "json");
    
}

function clearError() {
    var spans = $("span.error");
    for (var i = 0; i < spans.length; i++) {
      $(spans[i]).empty();
    }

    $(".error").each(function () {
        this.parentNode.removeChild(this);
    });
}