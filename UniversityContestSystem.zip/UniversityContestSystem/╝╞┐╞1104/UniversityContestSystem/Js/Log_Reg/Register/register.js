﻿var userNum, userName, password, password2,email, userType;;

$(function () {//点击注册
    $("#butRegister").click(toRegister);
});

function toRegister() {//注册
    if (checkRegistere()) {
        register();  
    }
}

function register() {//注册
    clearError();
    url = "../../../Controller/Log_Reg/Register/RegisterController.aspx";
    var data = {
        "userNum": userNum,
        "userName": userName,
        "password": password,
        "email": email,
        "userType": userType
    };
    $.post(url, data, function (Result) {
        //alert(Result.registerStatus);
        e = $("#butRegister");
        sp = document.createElement("span");
        sp.className = "error";
        if (Result.registerStatus == "EMAIL_HAD_REGISTERED") {
            sp.innerHTML = "<font color='red'>您好，您填写的邮箱地址已被使用</font>";
        }
        else if (Result.registerStatus == "REGISTER_MAIL_FAILED") {
            sp.innerHTML = "<font color='red'>邮件发送失败，请检查网络</font>";
        }
        else {
            alert("注册成功，激活链接已发送到您的邮箱，激活之后即可登录");
            window.location = "../../home.aspx";
        }
        e.parent().append(sp);
    }, "json");
}

function checkRegistere() { //检查输入
    userNum = $("#userNum").attr("value");
    userName = $("#userName").attr("value");
    password = $("#rPassword").attr("value");
    password2 = $("#r2Password").attr("value");
    email = $("#email").attr("value");
    userType = $('input[name="type"]:checked').val();
    clearError();
    //alert("@@@"+userNum +"  "+userName+"  "+password+"  "+password2+"  "+email+"  "+userType);
    if (!(/^\d+$/.test(userNum))) {
        var e = $("#userNum");
        var sp = document.createElement("span");
        sp.className = "error";
        sp.innerHTML = "<font color='red'> *请正确填写用户号</font>";
        e.parent().append(sp);
        e.focus();
        return false;
    }
    else if (userName == "") {
        e = $("#userName");
        sp = document.createElement("span");
        sp.className = "error";
        sp.innerHTML = "<font color='red'> *请正确填写用户名</font>";
        e.parent().append(sp);
        e.focus();
        return false;
    }
    else if (password == "") {
        e = $("#rPassword");
        sp = document.createElement("span");
        sp.className = "error";
        sp.innerHTML = "<font color='red'> *请输入密码</font>";
        e.parent().append(sp);
        e.focus();
        return false;
    }
    else if (password2 != password) {
        e = $("#r2Password");
        sp = document.createElement("span");
        sp.className = "error";
        sp.innerHTML = "<font color='red'> *两次密码不一致</font>";
        e.parent().append(sp);
        e.focus();
        return false;
    }
    else if (!(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(email))) {
        e = $("#email");
        sp = document.createElement("span");
        sp.className = "error";
        sp.innerHTML = "<font color='red'> *请填写正确的邮箱地址</font>";
        e.parent().append(sp);
        e.focus();
        return false;
    }
    else {
        return true;
    }
}

function clearError() {
    //var spans = $("span.error");
    //for (var i = 0; i < spans.length; i++) {
      //  $(spans[i]).empty();
    //}

    $(".error").each(function () {
        this.parentNode.removeChild(this);
    });
}