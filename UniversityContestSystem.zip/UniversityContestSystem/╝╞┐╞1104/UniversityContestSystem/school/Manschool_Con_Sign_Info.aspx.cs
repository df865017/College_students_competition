﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient; 

public partial class school_Con_Sign_Info : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        sqlcon = new SqlConnection(strCon);
        sqlcon.Open();
        if (!IsPostBack)
        {
            string schoolName = Session["userName"].ToString();
            Label1.Text = schoolName;
           // Label1.Text = "北京化工大学";
            GridView1.Visible = false;
            GridView2.Visible = false;
            Button2.Visible = false;
            Button3.Visible = false;
            bind3();
            bind4();
        }        
    }
    SqlConnection sqlcon;
    string strCon = "Server =  .; DataBase =SoftwareProject;Integrated Security = TRUE";
    
    public void bind1()
    {
        string sqlstr;
        if (string.IsNullOrWhiteSpace(TextBox1.Text))
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                sqlstr = "select top 10 * from tb_stu_contest_per,tb_school where checkFlag_1 = '" + DropDownList2.Text + "' AND   school =sId  and  schoolName= '" + Label1.Text + "'";
            }
            else
            {
                sqlstr = "select top 10 * from tb_stu_contest_per,tb_school where school =schoolId and  checkFlag_1 = '" + DropDownList2.Text + "' AND  contestName='" + TextBox2.Text + "'AND schoolName = '" + Label1.Text + "'";
            }
        }
        else
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                sqlstr = "select top 10 * from tb_stu_contest_per,tb_school  where school =sId and checkFlag_1 = '" + DropDownList2.Text + "' AND studentName='" + TextBox1.Text + "' AND schoolName = '" + Label1.Text + "'";
            }
            else
            {
                sqlstr = "select top 10 * from tb_stu_contest_per,tb_school where school =sId and checkFlag_1 = '" + DropDownList2.Text + "' AND  studentName='" + TextBox1.Text + "' AND contestName='" + TextBox2.Text + "'  AND schoolName = '" + Label1.Text + "'";
            }
        }

        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "tb_Member");
        GridView1.DataSource = myds;
        GridView1.DataKeyNames = new string[] { "scpId" };
        GridView1.DataBind();
        sqlcon.Close();
    }
    public void bind2()
    {
        string sqlstr;
        if (string.IsNullOrWhiteSpace(TextBox1.Text))
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                sqlstr = "select top 10 * from tb_student_contest_team,tb_school where stu_school=sId and  checkflag_1 = '" + DropDownList2.Text + "' AND schoolName = '" + Label1.Text + "' and stu_kind ='是'";
            }
            else
            {
                sqlstr = "select top 10 * from tb_student_contest_team,tb_school where stu_school=sId and  checkflag_1 = '" + DropDownList2.Text + "' AND contest_name='" + TextBox2.Text + "'  AND schoolName = '" + Label1.Text + "' and stu_kind ='是'";
            }
        }
        else
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                sqlstr = "select top 10 * from tb_student_contest_team,tb_school where stu_school=sId and checkflag_1 = '" + DropDownList2.Text + "' and stu_kind ='是' AND team_name='" + TextBox1.Text + "'  AND schoolName= '" + Label1.Text + "'";
            }
            else
            {
                sqlstr = "select top 10 * from tb_student_contest_team,tb_school where stu_school=sId and checkflag_1 = '" + DropDownList2.Text + "' and stu_kind ='是' AND team_name='" + TextBox1.Text + "' AND contest_name='" + TextBox2.Text + "' AND schoolName='" + Label1.Text + "'";
            }
        }

        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "tb_Member");
        GridView2.DataSource = myds;
        GridView2.DataKeyNames = new string[] { "sctId" };
        GridView2.DataBind();
        sqlcon.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.Text == "团体赛")
        {
            GridView1.Visible = false;
            GridView2.Visible = true;
            
            bind2();
        }
        else
        {
            GridView1.Visible = true;
            GridView2.Visible = false;
            bind1();
        }
        Button2.Visible = Button3.Visible = true;
        if(DropDownList2.Text=="是")
        {
            Button2.Visible = false;
            Button3.Visible = true;
        }
        if (DropDownList2.Text == "否")
        {
            Button2.Visible = true;
            Button3.Visible = false; 
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (DropDownList1.Text != "团体赛")
        {
            sqlcon = new SqlConnection(strCon);
            SqlCommand sqlcom;
            for (int i = 0; i <= GridView1.Rows.Count - 1; i++)
            {
                CheckBox cbox = (CheckBox)GridView1.Rows[i].FindControl("CheckBox1");
                if (cbox.Checked == true)
                {
                    string sqlstr = "select num from tb_school_contest where schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "') and contestId =(select conId from tb_contest where conName=(select contestName from tb_stu_contest_per where scpId='" + GridView1.DataKeys[i].Value + "'))";
                    SqlDataAdapter dap = new SqlDataAdapter(sqlstr, sqlcon);
                    DataTable dt = new DataTable();
                    dap.Fill(dt);
                    if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
                    {
                        if (int.Parse(dt.Rows[0][0].ToString()) <= 0)
                        {
                            Response.Write("<script>alert('设置人数超过上限！'); </script>");
                            return;
                        }
                        else
                        {
                            sqlstr = "update tb_school_contest set num=num-1 where schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "') and contestId =(select conId from tb_contest where conName=(select contestName from tb_stu_contest_per where scpId='" + GridView1.DataKeys[i].Value + "'))";
                            sqlcon.Open();
                            sqlcom = new SqlCommand(sqlstr, sqlcon);
                            sqlcom.ExecuteNonQuery();
                        }
                    }
                    sqlstr = "update tb_stu_contest_per set checkFlag_1 = '是' where scpId='" + GridView1.DataKeys[i].Value + "'";
                    sqlcom = new SqlCommand(sqlstr, sqlcon);
                    sqlcom.ExecuteNonQuery();
                    //将审核通过的团队信息提交到tb_user_contest表中
                    sqlstr = "insert into tb_user_contest (userId,conId,schoolId,teacherId) values ((select user_id from tb_stu_contest_per where scpId='" + GridView1.DataKeys[i].Value + "'),(select conId from tb_contest,tb_stu_contest_per where tb_contest.conName=tb_stu_contest_per.contestName and tb_contest.contestKind=tb_stu_contest_per.contestKind and scpId='" + GridView1.DataKeys[i].Value + "'),(select school from tb_stu_contest_per where scpId='" + GridView1.DataKeys[i].Value + "'),(select tId from tb_teacher,tb_stu_contest_per where teaName=ZDteacher and scpId='" + GridView1.DataKeys[i].Value + "'))";
                    sqlcom = new SqlCommand(sqlstr, sqlcon);
                    //sqlcon.Open();
                    sqlcom.ExecuteNonQuery();
                    sqlcon.Close();
                }
            }
            bind1();
        }
        else
        {
            sqlcon = new SqlConnection(strCon);
            SqlCommand sqlcom;
            for (int i = 0; i <= GridView2.Rows.Count - 1; i++)
            {
                CheckBox cbox = (CheckBox)GridView2.Rows[i].FindControl("CheckBox2");
                if (cbox.Checked == true)
                {
                    string sqlstr = "select num from tb_school_contest where schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "') and contestId =(select conId from tb_contest where conName=(select contest_name from tb_student_contest_team where sctId='" + GridView2.DataKeys[i].Value + "'))";
                    SqlDataAdapter dap = new SqlDataAdapter(sqlstr, sqlcon);
                    DataTable dt = new DataTable();
                    dap.Fill(dt);
                    sqlcon.Open();
                    if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
                    {
                        if (int.Parse(dt.Rows[0][0].ToString()) <= 0)
                        {
                            Response.Write("<script>alert('设置人数超过上限！'); </script>");
                            return;
                        }
                        else
                        {
                            sqlstr = "update tb_school_contest set num=num-1 where schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "') and contestId =(select conId from tb_contest where conName=(select contest_name from tb_student_contest_team where sctId='" + GridView2.DataKeys[i].Value + "'))";
                            sqlcom = new SqlCommand(sqlstr, sqlcon);
                            sqlcom.ExecuteNonQuery();
                        }
                    }
                    sqlstr = "update tb_student_contest_team set checkflag_1 = '是'  where sctId='" + GridView2.DataKeys[i].Value + "'";
                    sqlcom = new SqlCommand(sqlstr, sqlcon);
                    //sqlcon.Open();
                    sqlcom.ExecuteNonQuery();

                    sqlstr = "insert into tb_team (teamName,teamNum,conId,schoolId,teacherId1,teacherId2) values ((select team_name from tb_student_contest_team where sctId='" + GridView2.DataKeys[i].Value + "'),(select id from tb_student_contest_team where sctId='" + GridView2.DataKeys[i].Value + "' and stu_kind='是'),(select conId from tb_contest,tb_student_contest_team where tb_contest.conName=tb_student_contest_team.contest_name and tb_contest.contestKind=tb_student_contest_team.contest_kind and sctId='" + GridView2.DataKeys[i].Value + "' and stu_kind='是'),(select stu_school from tb_student_contest_team where sctId='" + GridView2.DataKeys[i].Value + "'and stu_kind='是'),(select tId from tb_teacher where teaName=(select teacher1 from tb_student_contest_team where  sctId='" + GridView2.DataKeys[i].Value + "'and checkFlag_2='是' and  stu_kind='是')),(select tId from tb_teacher where teaName=(select teacher2 from tb_student_contest_team where checkFlag_3='是' and  sctId='" + GridView2.DataKeys[i].Value + "'and stu_kind='是')))";
                    sqlcom = new SqlCommand(sqlstr, sqlcon);
                    //sqlcon.Open();
                    sqlcom.ExecuteNonQuery();

                    //待实现功能：更新stu_team表

                    sqlcon.Close();
                }
            }
            bind2();
        }
        bind4();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (DropDownList1.Text != "团体赛")
        {
            sqlcon = new SqlConnection(strCon);
            SqlCommand sqlcom;
            for (int i = 0; i <= GridView1.Rows.Count - 1; i++)
            {
                CheckBox cbox = (CheckBox)GridView1.Rows[i].FindControl("CheckBox1");
                if (cbox.Checked == true)
                {
                    string sqlstr = "select num from tb_school_contest where schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "') and contestId =(select conId from tb_contest where conName=(select contestName from tb_stu_contest_per where scpId='" + GridView1.DataKeys[i].Value + "'))";
                    SqlDataAdapter dap = new SqlDataAdapter(sqlstr, sqlcon);
                    DataTable dt = new DataTable();
                    dap.Fill(dt);
                    if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
                    {
                        sqlstr = "update tb_school_contest set num=num+1 where schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "') and contestId =(select conId from tb_contest where conName=(select contestName from tb_stu_contest_per where scpId='" + GridView1.DataKeys[i].Value + "'))";
                        sqlcon.Open();
                        sqlcom = new SqlCommand(sqlstr, sqlcon);
                        sqlcom.ExecuteNonQuery();
                    }

                    sqlstr = "update tb_stu_contest_per set checkFlag_1 = '否' where scpId='" + GridView1.DataKeys[i].Value + "'";
                    sqlcom = new SqlCommand(sqlstr, sqlcon);
                    //sqlcon.Open();
                    sqlcom.ExecuteNonQuery();
                    sqlstr = "delete tb_user_contest where userId = (select user_id from tb_stu_contest_per where scpId= '" + GridView1.DataKeys[i].Value + "') and conId = (select conId from tb_stu_contest_per,tb_contest where scpId= '" + GridView1.DataKeys[i].Value + "' and tb_stu_contest_per.contestName=tb_contest.conName and tb_stu_contest_per.contestKind=tb_contest.contestKind)";
                    sqlcom = new SqlCommand(sqlstr, sqlcon);
                    sqlcom.ExecuteNonQuery();
                    //删除stu_team表中相应信息
                    sqlcon.Close();
                }
            }
            bind1();
        }
        else
        {
            sqlcon = new SqlConnection(strCon);
            SqlCommand sqlcom;
            for (int i = 0; i <= GridView2.Rows.Count - 1; i++)
            {
                CheckBox cbox = (CheckBox)GridView2.Rows[i].FindControl("CheckBox2");
                if (cbox.Checked == true)
                {
                    string sqlstr = "select num from tb_school_contest where schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "') and contestId =(select conId from tb_contest where conName=(select contest_name from tb_student_contest_team where sctId='" + GridView2.DataKeys[i].Value + "'))";
                    SqlDataAdapter dap = new SqlDataAdapter(sqlstr, sqlcon);
                    DataTable dt = new DataTable();
                    dap.Fill(dt);
                    sqlcon.Open();
                    if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
                    {
                        sqlstr = "update tb_school_contest set num=num+1 where schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "') and contestId =(select conId from tb_contest where conName=(select contest_name from tb_student_contest_team where sctId='" + GridView2.DataKeys[i].Value + "'))";
                        
                        sqlcom = new SqlCommand(sqlstr, sqlcon);
                        sqlcom.ExecuteNonQuery();
                    }
                    sqlstr = "update tb_student_contest_team set checkflag_1 = '否' where sctId='" + GridView2.DataKeys[i].Value + "'";
                   // sqlcon.Open();
                    sqlcom = new SqlCommand(sqlstr, sqlcon);
                    
                    sqlcom.ExecuteNonQuery();
                    sqlstr = "delete tb_team where teamName = (select team_name from tb_student_contest_team where sctId='" + GridView2.DataKeys[i].Value + "')and conId = (select conId from tb_student_contest_team,tb_contest where sctId= '" + GridView2.DataKeys[i].Value + "' and tb_student_contest_team.contest_name=tb_contest.conName and tb_student_contest_team.contest_Kind=tb_contest.contestKind)";
                    sqlcom = new SqlCommand(sqlstr, sqlcon);
                    sqlcom.ExecuteNonQuery();
                    sqlcon.Close();
                }
            }
            bind2();
        }
        bind4();
    }
    protected void bind3()
    {
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
        SqlDataAdapter dap = new SqlDataAdapter("select conName from tb_contest ", conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList3.Items.Clear();
        DropDownList3.DataSource = dt;
        //DropDownList1.DataTextField = "job_desc";
        DropDownList3.DataValueField = "conName";
        DropDownList3.DataBind();
        if (DropDownList3.Text == "")
        {
            DropDownList3.Visible = false;

        }
        else
        {
            DropDownList3.Visible = true;

        }    
    }
    protected void bind4()
    {
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
        SqlDataAdapter dap;
        DataTable dt = new DataTable();
        dap = new SqlDataAdapter("select num from tb_school_contest where contestId = (select conId from tb_contest where  conName='"+DropDownList3.Text+"') and schoolId = (select sId from tb_school where schoolName = '"+Label1.Text+"')",conn);
        dap.Fill(dt);
        if (dt.Rows.Count==0)
        {
            TextBox3.Text = "无限制";
        }
        else
        {
            TextBox3.Text = dt.Rows[0][0].ToString(); 
        }
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        for (int i = 0; i <= GridView1.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)GridView1.Rows[i].FindControl("CheckBox1");
            if (cbox.Checked == true)
            {
                cbox.Checked = true;
            }
            else
            {
                cbox.Checked = false;
            }
        }
    }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        for (int i = 0; i <= GridView2.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)GridView2.Rows[i].FindControl("CheckBox2");
            if (cbox.Checked == true)
            {
                cbox.Checked = true;
            }
            else
            {
                cbox.Checked = false;
            }
        }
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        bind4();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        string sqlstr = "select * from tb_school_contest where contestId = (select conId from tb_contest where conName='" + DropDownList3.Text + "') and schoolId = (select sId from tb_school where schoolName='"+Label1.Text+"')";
        SqlDataAdapter dap;
        DataTable dt = new DataTable();
        dap = new SqlDataAdapter(sqlstr, sqlcon);
        dap.Fill(dt);
        if (dt.Rows.Count != 0)
        {
            sqlstr = "update tb_school_contest set num = " + TextBox3.Text + "  where contestId = (select conId from tb_contest where conName='" + DropDownList3.Text + "')and schoolId = (select sId from tb_school where schoolName='" + Label1.Text + "')";
            SqlCommand sqlcom = new SqlCommand(sqlstr, sqlcon);
            sqlcom.ExecuteNonQuery();
        }
        else 
        {
            sqlstr = "insert into tb_school_contest(schoolId,contestId,num)values((select sId from tb_school where schoolName='" + Label1.Text + "'),(select conId from tb_contest where conName='" + DropDownList3.Text + "'),'" + TextBox3.Text + "')";
            SqlCommand sqlcom = new SqlCommand(sqlstr, sqlcon);
            sqlcom.ExecuteNonQuery();
        }
    }
}