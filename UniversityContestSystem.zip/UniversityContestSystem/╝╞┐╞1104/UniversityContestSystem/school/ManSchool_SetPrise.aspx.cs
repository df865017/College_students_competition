﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class school_ManSchool : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
    SqlDataAdapter dap;
    DataTable dt = new DataTable();
    protected void bindContestName()
    {
        string sqlstr = "select conName from tb_contest where schoolId = (select sId from tb_school where schoolName='" + Label1.Text + "')";
        dap = new SqlDataAdapter(sqlstr, conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList1.Items.Clear();
        DropDownList1.DataSource = dt;
        //DropDownList1.DataTextField = "job_desc";
        DropDownList1.DataValueField = "conName";
        DropDownList1.DataBind();
        if (DropDownList1.Text == "")
        {
            //  DropDownList5.Visible = false;
        }
        else
        {
            DropDownList1.Visible = true;
        }
    }
    protected void bindPrise()
    {
        string sqlstr = "select prise from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList1.Text + "')";
        dap = new SqlDataAdapter(sqlstr, conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList2.Items.Clear();
        DropDownList2.DataSource = dt;
        //DropDownList1.DataTextField = "job_desc";
        DropDownList2.DataValueField = "prise";
        DropDownList2.DataBind();
        if (DropDownList2.Text == "")
        {
            //  DropDownList5.Visible = false;
            Button4.Visible = false;
        }
        else
        {
            Button4.Visible = true;
        }
    }
    protected void bindNum()
    {
        if (DropDownList2.Text != "")
        {
            string sqlstr = "select num from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList1.Text + "') and prise='" + DropDownList2.Text + "'";
            dap = new SqlDataAdapter(sqlstr, conn);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            TextBox9.Text = dt.Rows[0][0].ToString(); 

        }
     //   Label16.Text = Label17.Text = Label18.Text = Label19.Text = Label20.Text = Label21.Text = Label22.Text = Label23.Text = "";
        
    }
    protected void bindGridView()
    {
        string sqlstr = "select top 10 * from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList1.Text + "')";
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr,conn);
        DataSet myds = new DataSet();
     //   conn.Open();
        myda.Fill(myds, "tb_Member");
        GridView1.DataSource = myds;
        //  GridView1.DataKeyNames = new string[] { "studentName" };
        GridView1.DataBind();
        conn.Close();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        string schoolName = Session["userName"].ToString();
        Label1.Text = schoolName; 
       // Label1.Text = "北京化工大学";
        if (!IsPostBack)
        {
            bindContestName();
            bindGridView();
            bindPrise();
            bindNum();
        }
        Label16.Text = Label17.Text = Label18.Text = Label19.Text = Label20.Text = Label21.Text = Label22.Text = Label23.Text = "";
        
        Label15.Text = "（小提示：将人数设置为0可删除该奖项）";
        conn.Open();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        SqlCommand cmd;
        if (TextBox9.Text == "")
        {
            Label15.Text = "*请输入人数"; 
        }
        else if (TextBox9.Text == "0")
        {
            cmd = new SqlCommand("delete from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList1.Text + "') and prise='" + DropDownList2.Text + "'", conn);
            cmd.ExecuteNonQuery();
        }
        else 
        {
            cmd = new SqlCommand("update tb_contest_prise set num='"+TextBox9.Text+"' where conId = (select conId from tb_contest where conName='" + DropDownList1.Text + "') and prise='" + DropDownList2.Text + "'", conn);
            cmd.ExecuteNonQuery();
        }
        bindGridView();
        bindPrise();
        bindNum();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        bindGridView();        
        bindPrise();
        bindNum();
    }
    protected void DropDownList2_TextChanged(object sender, EventArgs e)
    {
        bindNum();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Label16.Text = Label17.Text = Label18.Text = Label19.Text = Label20.Text = Label21.Text = Label22.Text = Label23.Text = "";
        SqlCommand cmd;
        if (TextBox1.Text != "" && TextBox2.Text != "")
        {
            dap = new SqlDataAdapter("select * from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList1.Text + "') and prise='" + TextBox1.Text + "'", conn);            
            DataTable dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count>0)
            {
                Label16.Text = "已设置该奖项，您可以在本页“修改奖项”模块查看并修改。";
            }
            else
            {
                cmd = new SqlCommand("insert into tb_contest_prise(conId,prise,num) values((select conId from tb_contest where conName='" + DropDownList1.Text + "'),'" + TextBox1.Text + "','" + TextBox2.Text + "')", conn);
                cmd.ExecuteNonQuery();
                TextBox1.Text = Label16.Text = TextBox2.Text = Label17.Text;
            }
        }
        else 
        {
            if (TextBox1.Text != "")
            {
                Label20.Text = "*请输入人数！"; 
            }
            else if (TextBox2.Text != "")
            {
                Label16.Text = "*请输入奖项名称！"; 
            }
        }
        if (TextBox3.Text != "" && TextBox4.Text != "")
        {
            dap = new SqlDataAdapter("select * from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList1.Text + "') and prise='" + TextBox3.Text + "'", conn);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Label17.Text = "已设置该奖项，您可以在本页“修改奖项”模块查看并修改。";
            }
            else
            {
                cmd = new SqlCommand("insert into tb_contest_prise(conId,prise,num) values((select conId from tb_contest where conName='" + DropDownList1.Text + "'),'" + TextBox3.Text + "','" + TextBox4.Text + "')", conn);
                cmd.ExecuteNonQuery();
                TextBox3.Text = Label18.Text = TextBox4.Text = Label19.Text;
            }
        }
        else
        {
            if (TextBox3.Text != "")
            {
                Label21.Text = "*请输入人数！";
            }
            else if (TextBox4.Text != "")
            {
                Label17.Text = "*请输入奖项名称！";
            }
        }
        if (TextBox5.Text != "" && TextBox6.Text != "")
        {
            dap = new SqlDataAdapter("select * from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList1.Text + "') and prise='" + TextBox5.Text + "'", conn);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Label18.Text = "已设置该奖项，您可以在本页“修改奖项”模块查看并修改。";
            }
            else
            {
                cmd = new SqlCommand("insert into tb_contest_prise(conId,prise,num) values((select conId from tb_contest where conName='" + DropDownList1.Text + "'),'" + TextBox5.Text + "','" + TextBox6.Text + "')", conn);
                cmd.ExecuteNonQuery();
                TextBox5.Text = Label20.Text = TextBox6.Text = Label21.Text;
            }
        }
        else
        {
            if (TextBox5.Text != "")
            {
                Label22.Text = "*请输入人数！";
            }
            else if (TextBox6.Text != "")
            {
                Label18.Text = "*请输入奖项名称！";
            }
        }
        if (TextBox7.Text != "" && TextBox8.Text != "")
        {
            dap = new SqlDataAdapter("select * from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList1.Text + "') and prise='" + TextBox7.Text + "'", conn);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Label19.Text = "已设置该奖项，您可以在本页“修改奖项”模块查看并修改。";
            }
            else
            {
                cmd = new SqlCommand("insert into tb_contest_prise(conId,prise,num) values((select conId from tb_contest where conName='" + DropDownList1.Text + "'),'" + TextBox7.Text + "','" + TextBox8.Text + "')", conn);
                cmd.ExecuteNonQuery();
                TextBox7.Text = Label19.Text = TextBox8.Text = Label20.Text;
            }
        }
        else
        {
            if (TextBox1.Text != "")
            {
                Label23.Text = "*请输入人数！";
            }
            else if (TextBox2.Text != "")
            {
                Label19.Text = "*请输入奖项名称！";
            }
        }
        bindGridView();
        bindPrise();
        bindNum();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Label16.Text = Label17.Text = Label18.Text = Label19.Text = Label20.Text = Label21.Text = Label22.Text = Label23.Text = "";
        TextBox1.Text = TextBox2.Text = TextBox3.Text = TextBox4.Text = TextBox5.Text = TextBox6.Text = TextBox7.Text = TextBox8.Text = "";
    }
}