﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient; 

public partial class school_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string schoolName = Session["userName"].ToString();
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
        SqlDataAdapter dap = new SqlDataAdapter("select schoolId from tb_contest,tb_school where sId=schoolId and schoolName='"+schoolName+"'", conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")   //承办学校
        {
            Response.Redirect("Home_man.aspx");
        }
        else
        {
            Response.Redirect("Home_con.aspx"); 
        }
    }
}