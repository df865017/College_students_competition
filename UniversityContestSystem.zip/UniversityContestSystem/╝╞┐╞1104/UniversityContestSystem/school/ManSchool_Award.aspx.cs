﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class school_ManSchool_Award : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
    SqlDataAdapter dap;
    DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
              
        if (!IsPostBack)
        {
            string schoolName = Session["userName"].ToString();
            Label1.Text = schoolName;
           // Label1.Text = "北京化工大学";
            cbind(); 
            abind_student();                
            ebind();            
            //DropDownList6.Items.Insert(0, new ListItem("撤销奖项", "撤销奖项"));           
        }
        conn.Open();
        //DropDownList6.Items.Insert(0, new ListItem("无", "无"));  
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd;
        if (DropDownList6.Text == "撤销奖项")
        {
            if (DropDownList2.Text == "个人")
            {
                cmd = new SqlCommand("update tb_user_contet set prise=null where userId=(select uid from tb_user where userName='" + DropDownList3.Text + "')and  conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd.ExecuteNonQuery();
            }
            else if (DropDownList2.Text == "团队")
            {
                cmd = new SqlCommand("update tb_team set prise=null where teamName='" + DropDownList3.Text + "' and conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd.ExecuteNonQuery();
            }
            else if (DropDownList2.Text == "老师")
            {
                // cmd = new SqlCommand("update tb_teacher_contest set prise=null where tId=(select tId from tb_teacher where teaName='" + DropDownList3.Text + "') and cId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd = new SqlCommand("delete tb_teacher_contest where  tId=(select tId from tb_teacher where teaName='" + DropDownList3.Text + "') and cId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd.ExecuteNonQuery();
            }
            else if (DropDownList2.Text == "学校")
            {
                //  cmd = new SqlCommand("update tb_school_prise set prise=null where schoolId=(select schoolId from tb_school where schoolName='" + DropDownList3.Text + "') and cId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd = new SqlCommand("delete tb_school_prise where schoolId=(select schoolId from tb_school where schoolName='" + DropDownList3.Text + "') and conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd.ExecuteNonQuery();
            }
            cmd = new SqlCommand("update tb_contest_prise set num=num+1 where conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "') and prise='" + Label4.Text + "'", conn);
            cmd.ExecuteNonQuery();
        }
        else if(DropDownList6.Text!="无")
        {
            if (DropDownList2.Text == "个人")
            {
                cmd = new SqlCommand("update tb_user_contest set prise='" + DropDownList6.Text + "' where userId=(select uId from tb_user where userName='" + DropDownList3.Text + "')and  conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd.ExecuteNonQuery();
            }
            else if (DropDownList2.Text == "团队")
            {
                cmd = new SqlCommand("update tb_team set prise='" + DropDownList6.Text + "' where teamName='" + DropDownList3.Text + "' and conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd.ExecuteNonQuery();
            }
            else if (DropDownList2.Text == "老师")
            {
                // cmd = new SqlCommand("update tb_teacher_contest set prise='" + DropDownList6.Text + "' where tId=(select tId from tb_teacher where teaName='" + DropDownList3.Text + "') and cId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd = new SqlCommand("insert into tb_teacher_contest(prise,tId,cId)values('" + DropDownList6.Text + "',(select tId from tb_teacher where teaName='" + DropDownList3.Text + "'), (select conId from tb_contest where conName = '" + DropDownList5.Text + "'))", conn);
                cmd.ExecuteNonQuery();
            }
            else if (DropDownList2.Text == "学校")
            {
                //cmd = new SqlCommand("update tb_school_prise set prise='" + DropDownList6.Text + "' where schoolId=(select sId from tb_school where schoolName='" + DropDownList3.Text + "') and conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd = new SqlCommand("insert into tb_school_prise (prise,schoolId,conId)values('" + DropDownList6.Text + "',(select sId from tb_school where schoolName='" + DropDownList3.Text + "'),(select conId from tb_contest where conName = '" + DropDownList5.Text + "'))", conn);
                cmd.ExecuteNonQuery();
            }
            cmd = new SqlCommand("update tb_contest_prise set num=num-1 where conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "') and prise='" + DropDownList6.Text + "'", conn);
            cmd.ExecuteNonQuery();
        }
        if (TextBox1.Text != "")
        {
            if (DropDownList2.Text == "个人")
            {
                cmd = new SqlCommand("update tb_user_contest set grade='" + TextBox1.Text + "' where userId=(select uId from tb_user where userName='" + DropDownList3.Text + "')and  conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd.ExecuteNonQuery();
            }
            else if (DropDownList2.Text == "团队")
            {
                cmd = new SqlCommand("update tb_team set grade='" + TextBox1.Text + "' where teamName='" + DropDownList3.Text + "' and conId = (select conId from tb_contest where conName = '" + DropDownList5.Text + "')", conn);
                cmd.ExecuteNonQuery();
            }

        }
        ebind();
    }
    protected  void abind_student()
    {
        dap = new SqlDataAdapter("select userName from tb_user_contest,tb_user where tb_user_contest.userId = tb_user.uid AND tb_user_contest.conId=(select conId from tb_contest where conName='" + DropDownList5.Text + "')", conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList3.Items.Clear();
        DropDownList3.DataSource = dt;
        //DropDownList1.DataTextField = "job_desc";
        DropDownList3.DataValueField = "userName";
        DropDownList3.DataBind();
        
    }
    protected void abind_team()
    {
        string sqlstr = "select teamName from tb_team where tb_team.conId=(select conId from tb_contest where  conName='" + DropDownList5.Text + "')";

        dap = new SqlDataAdapter(sqlstr, conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList3.Items.Clear();
        DropDownList3.DataSource = dt;
        //DropDownList1.DataTextField = "job_desc";
        DropDownList3.DataValueField = "teamName";
        DropDownList3.DataBind();
    }
    protected void abind_teacher()
    {

        string sqlstr = "select teaName from tb_teacher where tId in ((select teacherId1 from tb_team where conId=(select conId from tb_contest where  conName='" + DropDownList5.Text + "'))union (select teacherId2 from tb_team where conId=(select conId from tb_contest where  conName='" + DropDownList5.Text + "'))union(select teacherId from tb_user_contest where conId=(select conId from tb_contest where  conName='" + DropDownList5.Text + "')))";
        dap = new SqlDataAdapter(sqlstr, conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList3.Items.Clear();
        DropDownList3.DataSource = dt;
        //DropDownList1.DataTextField = "job_desc";
        DropDownList3.DataValueField = "teaName";
        DropDownList3.DataBind();
    }
    protected void abind_school()
    {
        string sqlstr = "select schoolName from tb_school where sId in ((select schoolId from tb_user_contest where conId=(select conId from tb_contest where  conName='" + DropDownList5.Text + "'))union(select schoolId from tb_team where conId=(select conId from tb_contest where  conName='" + DropDownList5.Text + "')))";
        dap = new SqlDataAdapter(sqlstr, conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList3.Items.Clear();
        DropDownList3.DataSource = dt;
        //DropDownList1.DataTextField = "job_desc";
        DropDownList3.DataValueField = "schoolName";
        DropDownList3.DataBind();
    }
    protected void cbind()
    {
        string sqlstr = "select conName from tb_contest where schoolId = (select sId from tb_school where schoolName='" + Label1.Text + "')";
        dap = new SqlDataAdapter(sqlstr, conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList5.Items.Clear();
        DropDownList5.DataSource = dt;
        //DropDownList1.DataTextField = "job_desc";
        DropDownList5.DataValueField = "conName";
        DropDownList5.DataBind();
    }
    protected void ebind()
    {
        TextBox1.Text = Label4.Text = "";
        if (DropDownList2.Text == "个人")
        {
            dap = new SqlDataAdapter("select prise from tb_user_contest where userId= (select uid from tb_user where userName = '" + DropDownList3.Text + "') and conId = (select conId from tb_contest where conName ='" + DropDownList5.Text + "' )", conn);
            DataTable dt2 = new DataTable();
            dap.Fill(dt2);
            if (dt2.Rows.Count > 0 && dt2.Rows[0][0].ToString() != "")
            // if(dt.Rows[0][0].ToString()!="")
            {
                DropDownList6.Items.Clear();
                DropDownList6.Items.Insert(0, new ListItem("撤销奖项", "撤销奖项"));
                //DropDownList6.Items.Insert(0, new ListItem("无", "无")); 
                Label4.Text = dt2.Rows[0][0].ToString();
            }
            else
            {
                string sqlstr = "select prise from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList5.Text + "') and num>0";
                dap = new SqlDataAdapter(sqlstr, conn);
                dt = new DataTable();
                dap.Fill(dt);
                DropDownList6.Items.Clear();
                DropDownList6.DataSource = dt;
                //DropDownList1.DataTextField = "job_desc";
                DropDownList6.DataValueField = "prise";
                DropDownList6.DataBind();
         //       DropDownList6.Items.Insert(0, new ListItem("无", "无"));
            }

            dap = new SqlDataAdapter("select grade from tb_user_contest where userId= (select uid from tb_user where userName = '" + DropDownList3.Text + "') and conId = (select conId from tb_contest where conName ='" + DropDownList5.Text + "' )", conn);

            DataTable dt1 = new DataTable();
            dap.Fill(dt1);
            if (dt1.Rows.Count > 0 && dt1.Rows[0][0].ToString() != "")
            {
                TextBox1.Text = dt1.Rows[0][0].ToString();
            }
        }
        else if (DropDownList2.Text == "团队")
        {
            dap = new SqlDataAdapter("select prise from tb_team where teamName = '" + DropDownList3.Text + "' and conId = (select conId from tb_contest where conName ='" + DropDownList5.Text + "' )", conn);
            dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                Label4.Text = dt.Rows[0][0].ToString();
                DropDownList6.Items.Clear();
                DropDownList6.Items.Insert(0, new ListItem("撤销奖项", "撤销奖项"));
            }
            else
            {
                string sqlstr = "select prise from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList5.Text + "') and num>0";
                dap = new SqlDataAdapter(sqlstr, conn);
                dt = new DataTable();
                dap.Fill(dt);
                DropDownList6.Items.Clear();
                DropDownList6.DataSource = dt;
                //DropDownList1.DataTextField = "job_desc";
                DropDownList6.DataValueField = "prise";
                DropDownList6.DataBind();
            }

            dap = new SqlDataAdapter("select grade from tb_team where teamName = '" + DropDownList3.Text + "' and conId = (select conId from tb_contest where conName ='" + DropDownList5.Text + "' )", conn);
            dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                TextBox1.Text = dt.Rows[0][0].ToString();
            }
        }
        else if (DropDownList2.Text == "老师")
        {
            dap = new SqlDataAdapter("select prise from tb_teacher_contest where tId=(select tId from tb_teacher where teaName = '" + DropDownList3.Text + "') and cId = (select conId from tb_contest where conName ='" + DropDownList5.Text + "' )", conn);
            dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                Label4.Text = dt.Rows[0][0].ToString();
                DropDownList6.Items.Clear();
                DropDownList6.Items.Insert(0, new ListItem("撤销奖项", "撤销奖项"));
            }
            else
            {
                string sqlstr = "select prise from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList5.Text + "') and num>0";
                dap = new SqlDataAdapter(sqlstr, conn);
                dt = new DataTable();
                dap.Fill(dt);
                DropDownList6.Items.Clear();
                DropDownList6.DataSource = dt;
                //DropDownList1.DataTextField = "job_desc";
                DropDownList6.DataValueField = "prise";
                DropDownList6.DataBind();
            }
        }
        else if (DropDownList2.Text == "学校")
        {
            dap = new SqlDataAdapter("select prise from tb_school_prise where schoolId=(select sId from tb_school where schoolName = '" + DropDownList3.Text + "') and conId = (select conId from tb_contest where conName ='" + DropDownList5.Text + "' )", conn);
            dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                Label4.Text = dt.Rows[0][0].ToString();
                DropDownList6.Items.Clear();
                DropDownList6.Items.Insert(0, new ListItem("撤销奖项", "撤销奖项"));
            }
            else
            {
                string sqlstr = "select prise from tb_contest_prise where conId = (select conId from tb_contest where conName='" + DropDownList5.Text + "') and num>0";
                dap = new SqlDataAdapter(sqlstr, conn);
                dt = new DataTable();
                dap.Fill(dt);
                DropDownList6.Items.Clear();
                DropDownList6.DataSource = dt;
                //DropDownList1.DataTextField = "job_desc";
                DropDownList6.DataValueField = "prise";
                DropDownList6.DataBind();
            }
        }
        DropDownList6.Items.Insert(0, new ListItem("无", "无"));
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList2.Text == "个人")
        {
            abind_student();

            Label3.Visible = TextBox1.Visible = true;
        }
        if (DropDownList2.Text == "团队")
        {
            abind_team();
            Label3.Visible = TextBox1.Visible = true;
        }
        if (DropDownList2.Text == "老师")
        {
            abind_teacher();
            Label3.Visible = TextBox1.Visible = false;
        }
        if (DropDownList2.Text == "学校")
        {
            abind_school();
            Label3.Visible = TextBox1.Visible = false;
        }
        ebind();
    }
    protected void DropDownList5_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList2.Text == "个人")
        {
            abind_student();

            Label3.Visible = TextBox1.Visible = true;
        }
        if (DropDownList2.Text == "团队")
        {
            abind_team();
            Label3.Visible = TextBox1.Visible = true;
        }
        if (DropDownList2.Text == "老师")
        {
            abind_teacher();
            Label3.Visible = TextBox1.Visible = false;
        }
        if (DropDownList2.Text == "学校")
        {
            abind_school();
            Label3.Visible = TextBox1.Visible = false;
        }
        ebind();
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        ebind();
    }
}