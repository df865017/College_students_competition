﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;

public partial class school_ManSchool_News_Upload : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Label1.Text = "北京化工大学";
          string schoolName = Session["userName"].ToString();
          Label1.Text = schoolName; 
    //    Image1.Visible = false;
    }
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true";
    SqlConnection sqlcon;
    SqlCommand sqlcom;
    protected void Button1_Click(object sender, EventArgs e)
    {
        if(TextBox1.Text!=""&&TextBox2.Text!="")
        {
            if (!FileUpload1.HasFile)
            {
                string str = "insert into tb_news(NewsTitle,News,Uploader,UploadDate) values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + Label1.Text + "','" + DateTime.Now + "')";
                sqlcon = new SqlConnection(strCon);
                sqlcon.Open();
                sqlcom = new SqlCommand(str, sqlcon);
                int result = sqlcom.ExecuteNonQuery();
                if (result > 0)
                {
                    Response.Write("<script>alert('发布成功！'); </script>");
                }
            }
            else 
            {
                string str = "insert into tb_news(NewsTitle,News,Uploader,UploadDate,Image)";
                string sqlstr = str + " values('" +TextBox1.Text + "','" + TextBox2.Text + "','" +Label1.Text + "','" + DateTime.Now + "',@imagedata)";
                sqlcon = new SqlConnection(strCon);
                sqlcon.Open();
                sqlcom = new SqlCommand(sqlstr, sqlcon);

                String imgPath = FileUpload1.PostedFile.FileName;
                String imgName = imgPath.Substring(imgPath.LastIndexOf("\\") + 1);
                String imgExtend = imgPath.Substring(imgPath.LastIndexOf(".") + 1);
                int FileLen = this.FileUpload1.PostedFile.ContentLength;
                Byte[] FileData = new Byte[FileLen];
                HttpPostedFile hp = FileUpload1.PostedFile;
                Stream sr = hp.InputStream;
                sr.Read(FileData, 0, FileLen);
                sqlcom.Parameters.Add("@imagedata", SqlDbType.Image);
                sqlcom.Parameters["@imagedata"].Value = FileData; /* */
                sqlcom.ExecuteNonQuery();
                sqlcon.Close();
                //sqlcom.ExecuteReader();
                Response.Write("<script>alert('发布成功！'); </script>");
            
            }            
        }
          
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = TextBox2.Text = "";
        //FileUpload1.Clear();
        //：：清除FileUpload1的内容
    }
}