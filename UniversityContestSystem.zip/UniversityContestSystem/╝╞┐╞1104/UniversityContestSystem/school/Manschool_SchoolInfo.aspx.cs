﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class school_SchoolInfoManage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string schoolName = Session["userName"].ToString();
        Label8.Text = schoolName; 
      //  Label8.Text = "北京化工大学";
        if (!IsPostBack)
        {
            TextBox1.Enabled = false;
            TextBox2.Enabled = false;
            TextBox3.Enabled = false;
            Button2.Visible = false;
            Button3.Visible = false;
            Button4.Visible = true;
            Label4.Text = Label6.Text = Label7.Text = "";
            String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_school where schoolName='"+Label8.Text+"'", conn);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                String name = rd["schoolName"].ToString();
                String[] s = name.Split(' ');
                name = s[0].ToString();
                TextBox1.Text = name;
                String email = rd["mail"].ToString();
                s = email.Split(' ');
                email = s[0].ToString();
                TextBox3.Text = email;
                String con = rd["schConName"].ToString();
                s = con.Split(' ');
                con = s[0].ToString();
                TextBox2.Text = con;
            }
            conn.Close(); 
        }
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox1.Enabled = false;
        TextBox2.Enabled = true;
        TextBox3.Enabled = true;
        Button2.Visible = true;
        Button3.Visible = true;
        Button4.Visible = true;
        Label4.Text  = Label6.Text = Label7.Text = "";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Enabled = false;
        TextBox2.Enabled = false;
        TextBox3.Enabled = false;
        Button2.Visible = false;
        Button3.Visible = false;
        Button4.Visible = true;
        Label4.Text  = Label6.Text = Label7.Text = "";
        String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        //检查输入学校参赛名称是否存在
        SqlCommand cmd = new SqlCommand("select * from tb_school where schConName='"+TextBox2.Text+"'", conn);
        int result = cmd.ExecuteNonQuery();
        
        if (result > 0)
        {
            Label6.Text = "*该参赛名称已存在，请更换";

        }
        else 
        {
            //检查输入邮箱格式是否正确
            if (!IsValidEmail(TextBox3.Text))
            {
                Label7.Text = "*邮箱格式不正确";
                //Label7.ForeColor = Red;
                TextBox1.Enabled = false;
                TextBox2.Enabled = true;
                TextBox3.Enabled = true;
                Button2.Visible = true;
                Button3.Visible = true;
                Button4.Visible = true;
                Label4.Text = Label6.Text  = "";
            }
                //待实现功能：向邮箱发送认证链接；检验邮箱是否重复
            else      //更新数据库
            {
                cmd = new SqlCommand("update tb_school set schConName='" + TextBox2.Text + "',mail='" + TextBox3.Text + "' where schoolName='" + Label8.Text + "'", conn);
                result=cmd.ExecuteNonQuery();
               if ( result> 0) 
               {
                   Response.Write("<script>alert('修改成功！')</script>");
                   TextBox1.Enabled = false;
                   TextBox2.Enabled = false;
                   TextBox3.Enabled = false;
                   Button2.Visible = false;
                   Button3.Visible = false;
                   Button4.Visible = true;
                   Label4.Text = Label6.Text = Label7.Text = "";
               }

            }
        }
        
    }
    public bool IsValidEmail (string strIn) 
    {
      return Regex.IsMatch(strIn, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"); 
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        TextBox1.Enabled = false;
        TextBox2.Enabled = false;
        TextBox3.Enabled = false;
        Button2.Visible = false;
        Button3.Visible = false;
        Button4.Visible = true;
        Label4.Text = Label6.Text = Label7.Text = "";
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        //待实现：修改数据库中相应项
        Label4.Text = "已经向教委提交重置密码申请，新密码将发送到您的邮箱，请留意。";
    }
}
