﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient; 

public partial class school_Con_Sign_Info : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GridView1.Visible = false;
            GridView2.Visible = false;
            string schoolName = Session["userName"].ToString();
            Label1.Text = schoolName;
           // Label1.Text = "北京化工大学";
        }
        
        
    }
    SqlConnection sqlcon;
    string strCon = "Server =  .; DataBase =SoftwareProject;Integrated Security = TRUE";
    public void bind1()
    {
        string sqlstr = "select top 10 * from tb_user_contest,tb_contest,tb_school,tb_user,tb_teacher where tb_user_contest.schoolId=sId and tb_user_contest.teacherId=tId and userId=uid and tb_user_contest.conId = tb_contest.conId AND  tb_contest.schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "')";
        if (string.IsNullOrWhiteSpace(TextBox1.Text))
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
              //  sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND   school = '" + Label1.Text + "'";
            }
            else
            {
                sqlstr += "and conName ='"+TextBox2.Text+"'";
        //        sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND  contestName='" + TextBox2.Text + "'AND school = '" + Label1.Text + "'";
            }
        }
        else
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                sqlstr += "and stuName='"+TextBox1.Text+"'";
       //         sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND studentName='" + TextBox1.Text + "' AND school = '" + Label1.Text + "'";
            }
            else
            {
                sqlstr += "and conName ='" + TextBox2.Text + "'" + "and stuName='" + TextBox1.Text + "'";
              //  sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND  studentName='" + TextBox1.Text + "' AND contestName='" + TextBox2.Text + "'  AND school = '" + Label1.Text + "'";
            }
        }

        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "tb_Member");
        GridView1.DataSource = myds;
       // GridView1.DataKeyNames = new string[] { "studentName" };
        GridView1.DataBind();
        sqlcon.Close();
    }
    public void bind2()
    {
        string sqlstr;
        sqlstr = "select top 10 * from tb_team,tb_contest,tb_school where  tb_team.schoolId=sId and tb_team.conId = tb_contest.conId AND tb_contest.schoolId=(select sId from tb_school where schoolName='" + Label1.Text + "')";
        if (string.IsNullOrWhiteSpace(TextBox1.Text))
        {

            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                //sqlstr = "select top 10 * from tb_student_contest_team where checkflag_2 = '" + DropDownList2.Text + "' AND stu_school='" + Label1.Text + "'";
            }
            else
            {
                sqlstr += "and conName ='" + TextBox2.Text + "'";
               // sqlstr = "select top 10 * from tb_student_contest_team where checkflag_2 = '" + DropDownList2.Text + "' AND contest_name='" + TextBox2.Text + "'  AND stu_school='" + Label1.Text + "'";
            }
        }
        else
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                sqlstr += "and teamName='"+TextBox1.Text+"'";
              //  sqlstr = "select top 10 * from tb_student_contest_team where checkflag = '" + DropDownList2.Text + "' AND team_name='" + TextBox1.Text + "'  AND stu_school='" + Label1.Text + "'";
            }
            else
            {
                sqlstr += "and conName ='" + TextBox2.Text + "'" + "ands teamName='" + TextBox1.Text + "'";
                //sqlstr = "select top 10 * from tb_student_contest_team where checkflag = '" + DropDownList2.Text + "'  AND team_name='" + TextBox1.Text + "' AND contest_name='" + TextBox2.Text + "' AND stu_school='" + Label1.Text + "'";
            }
        }

        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "tb_Member");
        GridView2.DataSource = myds;
       // GridView2.DataKeyNames = new string[] { "team_name" };
        GridView2.DataBind();
        sqlcon.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.Text == "团体赛")
        {
            GridView1.Visible = false;
            GridView2.Visible = true;
            
            bind2();
        }
        else
        {
            GridView1.Visible = true;
            GridView2.Visible = false;
            bind1();
        }
        
    }
   

}