﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient; 

public partial class school_Con_Award_Info : System.Web.UI.Page
{
    SqlConnection sqlcon;
    string strCon = "Server =  .; DataBase =SoftwareProject;Integrated Security = TRUE";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //Label1.Text = "北京化工大学";
            GridView1.Visible = false;
            GridView1.Visible = false;
            string schoolName = Session["userName"].ToString();
            Label1.Text = schoolName;
        }
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.Text == "团体赛")
        {
            GridView1.Visible = false;
            GridView2.Visible = true;

            bind2();
        }
        else
        {
            GridView1.Visible = true;
            GridView2.Visible = false;
            bind1();
        }
    }
    public void bind1()
    {
        string sqlstr;
        sqlstr = "select top 10 * from tb_user,tb_user_contest,tb_contest,tb_school where tb_user_contest.userId = tb_user.uid AND tb_user_contest.conId=tb_contest.conId AND tb_user_contest.schoolId=tb_school.sId  AND   tb_school.schoolName = '" + Label1.Text + "'";
            
        if (string.IsNullOrWhiteSpace(TextBox1.Text))
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
               // sqlstr = "select top 10 * from tb_user,tb_user_contest,tb_contest,tb_school where tb_user_contest.userId = tb_user.uid AND tb_user_contest.conId=tb_contest.conId AND tb_user_contest.schoolId=tb_school.sId ";
            }
            else
            {
                //sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND  contestName='" + TextBox2.Text + "'AND school = '" + Label1.Text + "'";
                sqlstr += "AND tb_contest.conName='"+TextBox2.Text+"'";
            }
        }
        else
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                sqlstr += "AND tb_user.userName='"+TextBox1.Text+"'";
               // sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND studentName='" + TextBox1.Text + "' AND school = '" + Label1.Text + "'";
            }
            else
            {
                sqlstr += "AND tb_user.userName='" + TextBox1.Text + "'" + "AND tb_contest.conName='" + TextBox2.Text + "'";
               // sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND  studentName='" + TextBox1.Text + "' AND contestName='" + TextBox2.Text + "'  AND school = '" + Label1.Text + "'";
            }
        }

        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "tb_Member");
        GridView1.DataSource = myds;
      //  GridView1.DataKeyNames = new string[] { "studentName" };
        GridView1.DataBind();
        sqlcon.Close();
    }
    public void bind2()
    {
        string sqlstr;
        sqlstr = "select top 10 * from tb_team,tb_contest,tb_school where tb_team.conId=tb_contest.conId AND tb_team.schoolId=tb_school.sId  AND   tb_school.schoolName = '" + Label1.Text + "'";

        if (string.IsNullOrWhiteSpace(TextBox1.Text))
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                // sqlstr = "select top 10 * from tb_user,tb_user_contest,tb_contest,tb_school where tb_user_contest.userId = tb_user.uid AND tb_user_contest.conId=tb_contest.conId AND tb_user_contest.schoolId=tb_school.sId ";
            }
            else
            {
                //sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND  contestName='" + TextBox2.Text + "'AND school = '" + Label1.Text + "'";
                sqlstr += "AND tb_contest.conName='" + TextBox2.Text + "'";
            }
        }
        else
        {
            if (string.IsNullOrWhiteSpace(TextBox2.Text))
            {
                sqlstr += "AND tb_team.teamName='" + TextBox1.Text + "'";
                // sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND studentName='" + TextBox1.Text + "' AND school = '" + Label1.Text + "'";
            }
            else
            {
                sqlstr += "AND tb_team.teamName='" + TextBox1.Text + "'" + "AND tb_contest.conName='" + TextBox2.Text + "'";
                // sqlstr = "select top 10 * from tb_stu_contest_per where checkFlag_2 = '" + DropDownList2.Text + "' AND  studentName='" + TextBox1.Text + "' AND contestName='" + TextBox2.Text + "'  AND school = '" + Label1.Text + "'";
            }
        }

        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "tb_Member");
        GridView2.DataSource = myds;
        //  GridView1.DataKeyNames = new string[] { "studentName" };
        GridView2.DataBind();
        sqlcon.Close();
    }
}