﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///LoginService 的摘要说明
/// </summary>
public class LoginService
{
    public string login(String userSession,string userName, string password, string userType,out int id)
    {
         LoginDao loginDao = new LoginDao();
        //检查是否已经登录
        bool isSuccess = false;
        int isActive = 0;//默认未激活
        id = -1;
        if (loginDao.checkLogin(userSession,userName, password, userType,out isSuccess,out isActive,out id))
        {///已经登录
            return "LOGIN_SUCCESS"; //已经登录，和登录一样，直接跳转到个人主页
        }
        ///登录成功
        if (isSuccess)
        {
            if (isActive == 0)//未激活
            {
                return "NOT_ACTIVED";
            }
            else { //已激活，登录成功
                return "LOGIN_SUCCESS";;
            }
            
        } 
        ///登录失败
        return "LOGIN_FAIL";
    }
}