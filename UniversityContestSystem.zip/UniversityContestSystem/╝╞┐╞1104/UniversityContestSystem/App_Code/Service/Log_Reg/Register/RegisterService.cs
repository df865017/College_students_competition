﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Common;
using System.Text;

/// <summary>
///RegisterService 的摘要说明
/// </summary>
public class RegisterService
{
    RegisterDao registerDao = new RegisterDao(); 
        //注册
        public string register(string userNum, string userName, string password,  string email,string type)
        {
            ///生成激活码
            string activeCode = CommonOprations.GetRnd(16);
            tb_user user = null;
            byte userType = byte.Parse(type);
            ///存储注册的用户信息
            switch (userType)
            {
                case 1 :
                    user = registerDao.studentRegister(userNum, userName, password, email,activeCode);
                    break ;
                case 2:
                    user = registerDao.teacherRegister(userNum, userName, password, email,activeCode);
                    break;
            }

              // if (user == null) return "EMAIL_HAD_REGISTERED";//邮箱已被注册过
            //发EMAIL，若失败则需用户重新注册
            try
            {
                string subject = "大学生竞赛--注册激活";
                StringBuilder contentBuilder = new StringBuilder();
                contentBuilder.Append("请单击以下链接完成激活");
                contentBuilder.Append("&nbsp;&nbsp;&nbsp;<a href='http://localhost:1104/UniversityContestSystem/Controller/Log_Reg/Active/ActiveController.aspx?activeCode=" +
                    activeCode +"'>点我激活</a>");
                string mailBody = contentBuilder.ToString();
                EMail eMail = new EMail("jike_1104@163.com", email);
                if (!eMail.sendMail(subject, mailBody, true,
                       "jike_1104@163.com", "jike1104"))//邮件发送失败，插入数据库的数据进行删除
                {
                    if (!registerDao.rollBack(user)) 
                            return "REGISTER_MAIL_FAILED";
                    return "REGISTER_MAIL_FAILED";
                }
                return "REGISTER_MAIL_SUCCESS";
            }
            catch (Exception ex)//邮件发送失败，插入数据库的数据进行删除
            {
                if (!registerDao.rollBack(user)) return "REGISTER_MAIL_FAILED";
                return "REGISTER_MAIL_FAILED";
            }
        }
}