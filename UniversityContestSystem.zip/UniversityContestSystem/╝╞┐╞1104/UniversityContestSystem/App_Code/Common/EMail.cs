﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;

    public class EMail
    {
        MailMessage Email;
        SmtpClient Client = new SmtpClient("smtp.163.com", 25);
        public EMail(string from, string to)
        {
            Email = new MailMessage(from, to);
        }
        // 发送邮件
        public bool sendMail(string subject, string MailBody,
               bool isBodyHtml, string userName, string password)
        {
            try
            {
                Email.Subject = subject;
                Email.Body = MailBody;
                Email.IsBodyHtml = true;
                Client.Credentials = new System.Net.NetworkCredential(userName, password);
                Client.Send(Email);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }