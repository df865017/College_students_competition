﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Common;

/// <summary>
///ActiveDao 的摘要说明
/// </summary>
public class ActiveDao
{
    public string active(string activeCode)
    {
        DbDataContext db = new DbDataContext();
        
        try
        {
            tb_user user = db.tb_user.SingleOrDefault
                (u => u.activeCode.Equals(activeCode));
            if (user != null)
            {
                if (user.isActive == 1)
                {
                    return "HAD_ACTIVED";//已经激活，提示不要重复激活
                }
                else//未激活，更改标志位进行激活 
                {
                    user.isActive = 1;
                    db.SubmitChanges();
                    return "ACTIVE_SUCCESS";//激活成功
                }
            }
            else//未找到待激活的用户，激活失败
            {
                return "ACTIVE_FAIL";
            }
        }
        catch (Exception e) {//产生异常，激活失败
            return "ACTIVE_FAIL";
        }
    }
}