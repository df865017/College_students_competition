﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Common;


/// <summary>
///LoginDao 的摘要说明
/// </summary>
public class LoginDao
{
    DbDataContext db = new DbDataContext();
    /// 用户类型------
    ///    0 ： 教委用户--
    ///    1 ： 学生用户--
    ///    2 ： 教师用户--
    ///    3 ： 学校用户--
    public bool checkLogin(string userSession,string userName, string password, string userType,out bool isSuccess,out int isActive,out int id)
    {
        id = -1;
        isSuccess = false;
        isActive = 0;
        int userKind=int.Parse(userType);
        if (userKind == 0)
        {            
            tb_admin admin = db.tb_admin.SingleOrDefault(u => u.adName.Equals(userName) && u.password.Equals(password));
            if (admin != null)
            {
                id = admin.aId;                
                ///用户是否已经登录
                
                ///
                if (admin.adName.Equals(userSession))
                {
                    HttpContext.Current.Session["userName"] = admin.adName;  //
                    HttpContext.Current.Session["userId"] = admin.aId;                    
                    return true;//当前要登录的用户和存在的session相同，已登录
                }
                HttpContext.Current.Session["userId"] = admin.aId;
                HttpContext.Current.Session["userName"] = admin.adName;                                
                isSuccess = true;
                isActive = 1;
                return false;//不相同，未登录
            }
            return false;
        }
        if (userKind == 3)
        {
            tb_school school =db.tb_school.SingleOrDefault(s => s.schoolName.Equals(userName) && s.password.Equals(password));
            if (school != null)
            {
                if (school.schoolName.Equals(userSession))
                {
                    HttpContext.Current.Session["userName"] = school.schoolName;  //
                    HttpContext.Current.Session["userId"] = school.sId;
                    return true;//当前要登录的用户和存在的session相同，已登录
                }
                HttpContext.Current.Session["userId"] = school.sId;
                HttpContext.Current.Session["userName"] = school.schoolName;                                
                isSuccess = true;
                isActive = 1;
                return false;//不相同，未登录
            }
        }
        if (userKind == 1 || userKind == 2)
        {
            tb_user user = db.tb_user.SingleOrDefault
            (u => u.userName.Equals(userName) && u.password.Equals(password) && u.userType.Equals(userType)); //检索数据库语句
            ///用户是否登录成功
            ///           
            if (user != null)
            {
                id = user.uid;
                int userNum = user.userNum;
                ///用户是否已经登录

                ///
                if (user.mail.Equals(userSession))
                {
                    HttpContext.Current.Session["userName"] = user.userName;  //
                    HttpContext.Current.Session["userId"] = user.uid;
                    HttpContext.Current.Session["userNum"] = user.userNum;
                    HttpContext.Current.Session["userEmail"] = user.mail;
                    return true;//当前要登录的用户和存在的session相同，已登录
                }
                HttpContext.Current.Session["userId"] = user.uid;
                HttpContext.Current.Session["userName"] = user.userName;
                HttpContext.Current.Session["userNum"] = user.userNum;
                HttpContext.Current.Session["userEmail"] = user.mail;
                isActive = user.isActive;
                isSuccess = true;
                return false;//不相同，未登录
            }
            userName = null;
            return false;
        }
        return false;    
    }

}