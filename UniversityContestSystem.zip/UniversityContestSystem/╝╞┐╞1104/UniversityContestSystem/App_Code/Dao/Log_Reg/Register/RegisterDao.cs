﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Common;

/// <summary>
///RegisterDao 的摘要说明
/// </summary>
public class RegisterDao
{
    DbDataContext db = new DbDataContext();
    // 学生注册
    public tb_user studentRegister(string userNum, string userName, string password, string email,string activeCode)
    {
        //根据邮箱地址检查用户是否已经存在
       // if (userExist(email))
       // {
       //     return null;
       // }

        //用户不存在
        try
        {
            ///添加学生信息到学生表中
            tb_student student = new tb_student()
            {
                stuNum = int.Parse(userNum),
                stuName = userName,
                password = password,
                mail = email,
            };
            db.tb_student.InsertOnSubmit(student);
            db.SubmitChanges();

            ///在用户账户和权限表中添加未激活的记录
            tb_user user = new tb_user()
            {
                userNum = int.Parse(userNum),
                userName = userName,
                password = password,
                userType = 1,//学生
                mail = email,
                isActive = 0,//未激活
                activeCode = activeCode,
                fkId = student.uid
            };
            db.tb_user.InsertOnSubmit(user);
            db.SubmitChanges();
            return user;
        }
        catch (Exception e)
        {
            return null;
        }
    }

    // 教师注册
    public tb_user teacherRegister(string userNum, string userName, string password, string email, string activeCode)
    {
        //根据邮箱地址检查用户是否已经存在
        // if (userExist(email))
        //{
        //   return null;
        // }

        //用户不存在
        try
        {
            ///添加教师信息到教师表中
            tb_teacher teacher = new tb_teacher()
            {
                teaNum = int.Parse(userNum),
                teaName = userName,
                password = password,
                mail = email,
            };
            db.tb_teacher.InsertOnSubmit(teacher);
            db.SubmitChanges();
            ///在用户账户和权限表中添加未激活的记录
            tb_user user = new tb_user()
            {
                userNum = int.Parse(userNum),
                userName = userName,
                password = password,
                userType = 2,//教师
                mail = email,
                isActive = 0,//未激活
                activeCode = activeCode,
                fkId = teacher.tid
            };
            db.tb_user.InsertOnSubmit(user);
            db.SubmitChanges();
            return user;
        }
        catch (Exception e)
        {
            return null;
        }
    }

    /// 用户类型------
    ///     1 ： 学生用户--
    ///     2 ： 教师用户--
    ///     3 ： 学校用户--
    ///     4 ： 教委用户--

    public bool userExist(string email)
    {
       tb_user user = db.tb_user.SingleOrDefault
            (u => u.mail.Equals(email) && u.isActive == 1);
       return user != null;//已存在 user!=null为true返回真
    }

    // 发生异常或邮件发送失败，已插入数据库的记录进行删除
    public bool rollBack(tb_user user)
    {
       if(user.userType == 1)//学生
       {
           if (delStudent((int)user.fkId) && delUser(user.uid)) {
               return true; 
           }    
           return false; 
       }
       else if (user.userType == 2)//教师
       {
           if (delTeacher((int)user.fkId) && delUser(user.uid)) {
               return true;
           }          
           return false;
        }
        else 
           return false;
 
    }
    /// 从tb_user表中删除记录
    public bool delUser(int uid)
    {
        try
        {
            tb_user user = db.tb_user.SingleOrDefault
                (u => u.uid == uid);
            if (user != null)
            {
                db.tb_user.DeleteOnSubmit(user);
                db.SubmitChanges();
            }
            return true;
        }
        catch (Exception e) 
        {
            return false; 
        }
    }

    // 删除老师
    public bool delTeacher(int tId)
    {
        try
        {
            tb_teacher teacher = db.tb_teacher.SingleOrDefault
                (t => t.tid == tId);
            if (teacher != null)
            {
                db.tb_teacher.DeleteOnSubmit(teacher);
                db.SubmitChanges();
            }
            return true;
        }
        catch (Exception e)
        {
            return false; 
        }
    }

    /// 删除学生
    public bool delStudent(int sId)
    {
        try
        {
            tb_student student = db.tb_student.SingleOrDefault
                (s => s.uid == sId);
            if (student != null)
            {
                db.tb_student.DeleteOnSubmit(student);
                db.SubmitChanges();
            }
            return true;
        }
        catch (Exception e) 
        {
            return false; 
        }
    }
}