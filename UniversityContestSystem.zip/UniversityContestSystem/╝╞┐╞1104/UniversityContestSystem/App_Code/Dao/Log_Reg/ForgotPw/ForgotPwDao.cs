﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Common;
using System.Text;

/// <summary>
///ForgotPwDao 的摘要说明
/// </summary>
public class ForgotPwDao
{
    DbDataContext db = new DbDataContext();
    public string sendPw(string userName)
    {
        tb_user user = db.tb_user.SingleOrDefault
            (u => u.userName.Equals(userName) && u.isActive == 1);
        if (user != null)//找到已经激活的注册用户
        {
            //向邮箱中发送密码
            try
            {
                string randPw = CommonOprations.GetRnd(16);//生成16位随机密码
                string subject = "大学生竞赛--邮箱获取密码";
                StringBuilder contentBuilder = new StringBuilder();
                contentBuilder.Append("新密码为：" + randPw);
                string mailBody = contentBuilder.ToString();
                EMail eMail = new EMail("jike_1104@163.com", user.mail);
                if (!eMail.sendMail(subject, mailBody, true,
                       "jike_1104@163.com", "jike1104"))
                {
                    return "SEND_PW_FAILED";//发送密码失败
                }
                //修改数据库user表中的密码
                user.password = randPw;
                db.SubmitChanges();
                switch (user.userType)
                {
                    case 0:
                        tb_admin admin = db.tb_admin.SingleOrDefault
                            (a => a.aId == user.fkId);
                        admin.password = randPw;
                        db.SubmitChanges();
                        break;
                    case 1:
                        tb_student student = db.tb_student.SingleOrDefault
                            (s => s.uid == user.fkId);
                        student.password = randPw;
                        db.SubmitChanges();
                        break;
                    case 2:
                        tb_teacher teacher = db.tb_teacher.SingleOrDefault
                            (t => t.tid == user.fkId);
                        teacher.password = randPw;
                        db.SubmitChanges();
                        break;
                    case 3:
                        tb_school school = db.tb_school.SingleOrDefault
                            (sc => sc.sId == user.fkId);
                        school.password = randPw;
                        db.SubmitChanges();
                        break;
                }
                //

                return "SEND_PW_SUCCESS";//发送密码成功
            }
            catch (Exception ex)
            {
                return "SEND_PW_FAILED";//发送密码失败
            }
        }
        return "USER_NOT_EXIST";//用户不存在或未激活
    }
}