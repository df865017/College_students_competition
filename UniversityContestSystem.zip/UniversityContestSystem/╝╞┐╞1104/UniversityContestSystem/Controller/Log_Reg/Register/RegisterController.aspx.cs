﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Controller_Log_Reg_Register_RegisterController : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        RegisterService registerService = new RegisterService();
        string userNum = Request["userNum"];
        string userName = Request["userName"];
        string password = Request["password"];
        string email = Request["email"];
        string userType = Request["userType"];

        string registerStatus = "";
        registerStatus = registerService.register(userNum, userName, password,
                         email, userType);

        Response.Write("{\"registerStatus\":\"" + registerStatus + "\"}");
        Response.End();
    }
}