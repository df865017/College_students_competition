﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Controller_Log_Reg_Login_LoginController : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LoginService loginService = new LoginService();
        string userSession = "";
        if (Session["userName"] != null)
        {
            userSession = Session["userName"].ToString();
            
        }
        string txtValidate = Request["txtValidate"];
        string loginStatus = "";
        int id = -1;
        if (checkCode(txtValidate))
        {

            string userName = Request["userName"];
            string userEmail = Request["userEmail"];
            string password = Request["password"];
            string userType = Request["userType"];
            loginStatus = loginService.login(userSession, userName, password, userType, out id);
            if (loginStatus.Equals("LOGIN_SUCCESS"))   //输入存储
            {
                Session["userEmail"] = userEmail;
                Session["password"] = password;
                Session["userType"] = userType;
            }                      
        }
        else 
        {
            loginStatus = "CODE_ERROR";
        }
       // Response.Write("{\"loginStatus\":\"" + loginStatus + "\",\"id\":\""+id+"\"}");
        Response.Write("{\"loginStatus\":\"" + loginStatus + "\"}");
       //  Response.Redirect("../../../Page/Base_Info/student1.aspx");
        Response.End();
    }

    protected bool checkCode(string txtValidate)
    { 
        string userCode = txtValidate; //获取用户输入的验证码  
        if (String.IsNullOrEmpty(userCode))
        {
            //请输入验证码  
            return false;
        }

        string validCode = this.Session["CheckCode"] as String;  //获取系统生成的验证码  
        if (!string.IsNullOrEmpty(validCode))
        {
            if (userCode.ToLower() == validCode.ToLower())
            {
                //验证成功  
                return true;
            }
        }
        //验证失败  
        return false;
    }
}
