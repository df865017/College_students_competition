﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Controller_Log_Reg_Active_ActiveController : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ActiveService activeService = new ActiveService();

        string activeCode = Request["activeCode"];
        //string userId = Request["id"];

        string replyStr = activeService.active( activeCode);

        Response.Redirect("../../../Page/Log_Reg/Active/active.aspx?replyStr=" + replyStr);

        /*if (replyStr.Equals("ACTIVE_SUCCESS"))//激活成功
        {
            //跳转到personal页
            Response.Redirect("../../../Page/Log_Reg/Active/active.aspx?replyStr=");
        }
        else if (replyStr.Equals("ACTIVE_FAIL"))
        { //激活失败，跳转到home页
            Response.Redirect("../../../Page/personal.aspx");
        }
        else 
        {
            
        }*/  //~/Page/Log_Reg/Active/active.aspx
    }
}