﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Controller_Log_Reg_ForgotPw_ForgotPwController : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ForgotPwService forgotPwService = new ForgotPwService();

        string getPwStatus = forgotPwService.getPw(Request["userName"]);

        Response.Write("{\"getPwStatus\":\"" + getPwStatus + "\"}");
        Response.End();
    }
}