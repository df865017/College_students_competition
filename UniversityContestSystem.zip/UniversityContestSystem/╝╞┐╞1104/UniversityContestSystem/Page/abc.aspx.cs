﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_abc : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int type = int.Parse(Session["userType"].ToString());
        if (type == 0)
        {
            Response.Write("<script>location.href='../jiaowei/home.aspx';</script>");
        }
        if (type == 1)
        {
            Response.Write("<script>location.href='../student/explain.aspx';</script>");
        }
        if (type == 2)
        {
            Response.Write("<script>location.href='../Page/Con_Apply/teacher/teacher1.aspx';</script>");
        }
        if (type == 3)
        {
            Response.Write("<script>location.href='../school/Home.aspx';</script>");
        }
    }
}