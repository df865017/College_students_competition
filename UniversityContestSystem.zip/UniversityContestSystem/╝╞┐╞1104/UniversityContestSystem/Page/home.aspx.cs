﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //再此加载主页的所有信息，包括标题、新闻、学校信息、登录块等等
        if (Session["userName"] != null)
            lable1.Text = Session["userName"].ToString();
    }
}