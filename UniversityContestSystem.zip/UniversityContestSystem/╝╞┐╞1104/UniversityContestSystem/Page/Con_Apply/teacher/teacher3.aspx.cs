﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class Page_Con_Apply_teacher_Default : System.Web.UI.Page
{
    string name = null;
    SqlConnection sqlcon;
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            name = Session["userName"].ToString();
            bind();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        name = Session["userName"].ToString();
        GridViewRow src = ((GridViewRow)(((System.Web.UI.WebControls.Button)(e.CommandSource)).Parent.Parent));
        string id = GridView1.DataKeys[src.RowIndex].Value.ToString();
        string sqlstr = "select grade,prise from tb_user_contest where ucid='" + id + "'";
        string contestname = GridView1.Rows[src.RowIndex].Cells[4].Text;
        string studentname = GridView1.Rows[src.RowIndex].Cells[2].Text;
        string grade = null;
        string prise = null;
        sqlcon = new SqlConnection(strCon);
        sqlcon.Open();
        SqlDataReader rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
        while (rd.Read())
        {
            string[] s = rd["grade"].ToString().Split(' ');
            grade = s[0].ToString();

            s = rd["prise"].ToString().Split(' ');
            prise = s[0].ToString();
        }

        string str = "竞赛名称：" + contestname + "\\n" + "学生名：" + studentname + "\\n" + "成绩：" + grade + "\\n" + "奖项：" + prise;
        // Label5.Text = contestname;
        Response.Write("<script Language='JavaScript'>alert('" + str + "')</script>");
        sqlcon.Close();
    }
    protected void bind()
    {
        string sqlstr = "select ucid as '编号', userName as '学生名',userNum as '学号',conName as '竞赛名',tb_contest.contestKind as '竞赛类型',schoolName as '学校名'  from tb_user_contest,tb_user,tb_teacher,tb_contest,tb_school,tb_stu_contest_per where tb_user_contest.conId=tb_contest.conId and tb_user_contest.userId=tb_user.uid and (tb_contest.conName=tb_stu_contest_per.contestName	and tb_user_contest.schoolId=tb_school.sId and teaName='"+name+"' and (tb_stu_contest_per.checkFlag_2='是'))";
        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "tb_stu_contest_per,tb_school");
        GridView1.DataSource = myds;
        GridView1.DataKeyNames = new string[] { "编号" };//主键
        GridView1.DataBind();
        sqlcon.Close();
    }
    protected void PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
        bind();//重新绑定一遍数据
    }
}