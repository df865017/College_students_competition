﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class Page_Con_Apply_teacher_Default : System.Web.UI.Page
{
    SqlConnection sqlcon;    
    private string name = null;
    string teanum = null;
    string strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true";
    protected void Page_Load(object sender, EventArgs e)
    {
        name = Session["userName"].ToString();
        if(!IsPostBack){
            string sqlstr = "select * from tb_teacher where teaName ='"+name+"'";
            sqlcon = new SqlConnection(strconn);
            sqlcon.Open();
            SqlDataReader rd = new SqlCommand(sqlstr,sqlcon).ExecuteReader();
            string schID = null;
            while (rd.Read())
            {                
                String[] s = rd["teaNum"].ToString().Split(' ');                              
                TextBox1.Text = s[0].ToString();
                s = rd["teaName"].ToString().Split(' ');
                TextBox2.Text = s[0].ToString();
                s = rd["mail"].ToString().Split(' ');
                TextBox4.Text = s[0].ToString();

                s = rd["schoolId"].ToString().Split(' ');
                schID = s[0].ToString();
            }
            sqlcon.Close();
            sqlcon.Open();
            //int schid = int.Parse(schID);
            sqlstr = "select schoolName from tb_school where sId='"+schID+"'";
            rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            while (rd.Read())
            {
                String[] s = rd["schoolName"].ToString().Split(' ');
                DropDownList1.Text= s[0].ToString();
            }
            sqlcon.Close();
        }
    }      
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text == "" || TextBox4.Text == "")
        {
            Response.Write("<script>alert('请输入完整信息！')</script>");
        }
        else
        {
            string num = TextBox1.Text;
            string teaname = TextBox2.Text;
            string teamail = TextBox4.Text;
            string schname = DropDownList1.Text;
            
            string sID=null;
            sqlcon = new SqlConnection(strconn);
            sqlcon.Open();
            string sqlstr = "select sId from tb_school where schoolName='"+schname+"'";
            SqlDataReader rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            while (rd.Read())
            {
                String[] s = rd["sId"].ToString().Split(' ');
                sID = s[0].ToString();          
            }
            teanum = TextBox1.Text;            
            sqlcon.Close();
            sqlcon.Open();
            sqlstr = "update tb_teacher set teaName='" + teaname + "',mail='" + teamail + "', schoolId='" + sID + "' where teaNum='"+teanum+"' ";
            new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            sqlcon.Close();
            sqlcon.Open();
            sqlstr = "update tb_user set userName='" + teaname + "',mail='" + teamail + "' where userNum='" + teanum + "' ";
            new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            Session["userName"] = teaname;
            Response.Write("<script>alert('修改成功！')</script>");
        }
    }
}