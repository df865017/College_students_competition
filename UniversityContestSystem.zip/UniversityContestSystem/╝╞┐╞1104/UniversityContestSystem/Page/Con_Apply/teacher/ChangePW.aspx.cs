﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Page_Con_Apply_teacher_Default : System.Web.UI.Page
{
    SqlConnection sqlcon;
    SqlCommand sqlcom;
    private string name=null;
    string strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true";
    protected void Page_Load(object sender, EventArgs e)
    {

        name = Session["userName"].ToString();
    }     
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text != "" && TextBox2.Text != "" && TextBox3.Text != "")
        {
            string oldKey = TextBox1.Text;
            string newKey1 = TextBox2.Text;
            string newKey2 = TextBox3.Text;
            sqlcon = new SqlConnection(strconn);
            sqlcon.Open();
            string sqlstr = "select password from tb_teacher where teaName='"+name+"'";
            sqlcom = new SqlCommand(sqlstr,sqlcon);
            SqlDataReader rd = sqlcom.ExecuteReader();
            string psw = null;
            while (rd.Read())
            {
                psw = rd["password"].ToString();
                String[] s = psw.Split(' ');
                psw = s[0].ToString();
            }
            sqlcon.Close();
            if (psw == oldKey )
            {
                if (newKey1 == newKey2)
                {
                    sqlcon.Open();
                    sqlstr = "update tb_teacher set password='"+newKey1+"' where teaName='"+name+"' ";
                    new SqlCommand(sqlstr, sqlcon).ExecuteReader();
                    sqlcon.Close();
                    sqlcon.Open();
                    sqlstr = "update tb_user set password='" + newKey1 + "' where userName='" + name + "' ";
                    new SqlCommand(sqlstr, sqlcon).ExecuteReader();
                    sqlcon.Close();
                    Response.Write("<script>alert('修改成功！')</script>");
                }
                else
                {
                    Response.Write("<script>alert('两次输入不一致！')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('密码输入错误！')</script>");
            }
           
        }
        else
        {
            Response.Write("<script>alert('请输入完整信息！')</script>");
        }
    }
}