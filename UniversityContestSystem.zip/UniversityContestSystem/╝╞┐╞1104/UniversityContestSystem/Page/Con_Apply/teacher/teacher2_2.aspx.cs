﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class Page_Con_Apply_teacher_teacher2_2 : System.Web.UI.Page
{
    string name = null;
    SqlConnection sqlcon;
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            name = Session["userName"].ToString().Trim();
            bind();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string sqlstr = null;
        name = Session["userName"].ToString().Trim();
        if (e.CommandName == "pass")
        {
            GridViewRow src = ((GridViewRow)(((System.Web.UI.WebControls.Button)(e.CommandSource)).Parent.Parent));
            string id = GridView1.DataKeys[src.RowIndex].Value.ToString();
            string sqlstr1 = "select teacher1 from tb_student_contest_team where sctid='" + id + "'";
            sqlcon = new SqlConnection(strCon);
            sqlcon.Open();
            SqlDataReader rd = new SqlCommand(sqlstr1, sqlcon).ExecuteReader();
            string firstTeacher = null;
            while (rd.Read())
            {
                firstTeacher = rd["teacher1"].ToString();
                String[] s = firstTeacher.Split(' ');
                firstTeacher = s[0].ToString();
            }
            sqlcon.Close();
            if (firstTeacher == name)
            {
                sqlstr = "update tb_student_contest_team set checkflag_2='是' where  tb_student_contest_team.sctid='" + id + "'";
            }
            else
            {
                sqlstr = "update tb_student_contest_team set checkflag_3='是' where  tb_student_contest_team.sctid='" + id + "'";
            }
        }
        else
        {
            GridViewRow src = ((GridViewRow)(((System.Web.UI.WebControls.Button)(e.CommandSource)).Parent.Parent));
            string id = GridView1.DataKeys[src.RowIndex].Value.ToString();
            string sqlstr1 = "select teacher1 from tb_student_contest_team where sctid='" + id + "'";
            sqlcon = new SqlConnection(strCon);
            sqlcon.Open();
            SqlDataReader rd = new SqlCommand(sqlstr1, sqlcon).ExecuteReader();
            string firstTeacher = null;
            while (rd.Read())
            {
                firstTeacher = rd["teacher1"].ToString();
                String[] s = firstTeacher.Split(' ');
                firstTeacher = s[0].ToString();
            }
            sqlcon.Close();
            if (firstTeacher == name)
            {
                sqlstr = "update tb_student_contest_team set checkflag_2='否' where  tb_student_contest_team.sctid='" + id + "'";
            }
            else
            {
                sqlstr = "update tb_student_contest_team set checkflag_3='否' where  tb_student_contest_team.sctid='" + id + "'";
            }
        }

        sqlcon = new SqlConnection(strCon);
        sqlcon.Open();
        new SqlCommand(sqlstr, sqlcon).ExecuteNonQuery();
        sqlcon.Close();
        bind();
        Response.Redirect("teacher2_2.aspx");
    }
    protected void bind()
    {
        string sqlstr = "select sctid as '编号',team_name as '团队名',contest_name as '竞赛名',stu_name as '学生名',schoolName as '学校名',teacher1 as '指导老师1',teacher2 as '指导老师2' from tb_student_contest_team,tb_school where tb_school.sId=tb_student_contest_team.stu_school and ((teacher1='" + name + "' and checkflag_2 is null) or (teacher2='" + name + "' and checkflag_3 is null))";
        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "tb_team_teacher,tb_school");
        GridView1.DataSource = myds;
        GridView1.DataKeyNames = new string[] { "编号" };//主键
        GridView1.DataBind();
        sqlcon.Close();
    }
    protected void PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
        bind();//重新绑定一遍数据
    }
}