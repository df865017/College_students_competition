﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_Base_Info_MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack && Session["userName"] != null)//判断页面是否首次被加载
        {
             Label1.Text = Session["userName"].ToString();                     
            
        }
    }
}
