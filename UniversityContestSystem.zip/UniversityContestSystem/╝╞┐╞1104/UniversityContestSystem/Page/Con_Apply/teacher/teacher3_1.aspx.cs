﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class Page_Con_Apply_teacher_teacher3_1 : System.Web.UI.Page
{
    string name = null;
    SqlConnection sqlcon;
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            name = Session["userName"].ToString();
            bind();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        name = Session["userName"].ToString();
        GridViewRow src = ((GridViewRow)(((System.Web.UI.WebControls.Button)(e.CommandSource)).Parent.Parent));
        string id = GridView1.DataKeys[src.RowIndex].Value.ToString();
        string sqlstr = "select grade,prise from tb_team where tid='" + id + "'";
        string teamname = GridView1.Rows[src.RowIndex].Cells[2].Text;
        string contestname = GridView1.Rows[src.RowIndex].Cells[3].Text;
        string grade = null;
        string prise = null;
        sqlcon = new SqlConnection(strCon);
        sqlcon.Open();
        SqlDataReader rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
        while (rd.Read())
        {
            string[] s = rd["grade"].ToString().Split(' ');
            grade = s[0].ToString();
            s = rd["prise"].ToString().Split(' ');
            prise = s[0].ToString();
        }
        string str = "团队名：" + teamname + "\\n" + "竞赛名：" + contestname + "\\n" + "成绩：" + grade + "\\n" + "奖项：" + prise;
        Response.Write("<script Language='JavaScript'>alert('" + str + "')</script>");
        sqlcon.Close();
    }
    protected void bind()
    {
        string sqlstr = "select tid as '编号',tb_team.teamName as '团队名',contest_name as '竞赛名',stu_name as '学生名',schoolName as '学校名' from tb_team,tb_school,tb_student_contest_team where tb_team.teamNum=tb_student_contest_team.sctId and tb_team.schoolId=tb_school.sId and ((tb_student_contest_team.teacher1='lz' and checkflag_2='是') or (tb_student_contest_team.teacher2='lz' and checkflag_3='是'))";
        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "tb_team,tb_teacher,tb_student_contest_team,tb_school");
        GridView1.DataSource = myds;
        GridView1.DataKeyNames = new string[] { "编号" };//主键
        GridView1.DataBind();
        sqlcon.Close();
    }
    protected void PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
        bind();//重新绑定一遍数据
    }
}