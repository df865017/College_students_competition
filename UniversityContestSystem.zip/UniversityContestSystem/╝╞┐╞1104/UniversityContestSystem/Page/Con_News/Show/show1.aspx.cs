﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.ComponentModel;


    public partial class show : System.Web.UI.Page
    {
        SqlConnection sqlcon;
        string strCon = "Server = .; DataBase =SoftwareProject;Integrated Security = TRUE";
        string UserName = "校委";

        protected void Page_Load(object sender, EventArgs e)
        {
            // 获取上一个页面选定的新闻ID
            string NId = Request["NewsId"].ToString();

            // 判断用户，隐藏按钮
            if (UserName == "校委")
            {
                NEdit.Visible = true;
                NEdit.NavigateUrl = "/UniversityContestSystem/Page/Con_News/Revise/revise.aspx?NewsID=" + NId;
            }
            else NEdit.Visible = false;

            // 链接数据库
            sqlcon = new SqlConnection(strCon);
            sqlcon.Open();

            // 取得对应的新闻
            string sqlstr = "select NewsTitle,News from tb_news where NewsID='" + NId + "'";
            SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
            DataSet myds = new DataSet();
            myda.Fill(myds, "News");
            String NewsTtile = myds.Tables[0].Rows[0][0].ToString();
            String News = myds.Tables[0].Rows[0][1].ToString();

            // 显示
            NT.InnerText = NewsTtile;
            shownews.InnerText = News;

            // gridview的显示
            sqlstr = "select NewsID,NewsTitle,News,Uploader,PublicDate from tb_news where IsPubliced = 1 and NewsID != '" + NId + "' order by PublicDate desc";
            sqlcon = new SqlConnection(strCon);
            myda = new SqlDataAdapter(sqlstr, sqlcon);
            myds = new DataSet();
            sqlcon.Open();
            myda.Fill(myds, "News");
            GridView1.DataSource = myds;
            GridView1.DataKeyNames = new string[] { "NewsID" };//主键
            GridView1.DataBind();
            // 处理字符长度
            for (int i = 0; i <= GridView1.Rows.Count - 1; i++)
            {
                DataRowView mydrv;
                string gIntro;
                if (GridView1.PageIndex == 0)
                {
                    mydrv = myds.Tables["News"].DefaultView[i];//表名
                    gIntro = Convert.ToString(mydrv["News"]);//所要处理的字段
                    GridView1.Rows[i].Cells[3].Text = SubStr(gIntro, 30);
                    gIntro = Convert.ToString(mydrv["NewsTitle"]);//所要处理的字段
                    GridView1.Rows[i].Cells[2].Text = SubStr(gIntro, 10);
                }
                else
                {
                    mydrv = myds.Tables["News"].DefaultView[i + (5 * GridView1.PageIndex)];
                    gIntro = Convert.ToString(mydrv["News"]);
                    GridView1.Rows[i].Cells[3].Text = SubStr(gIntro, 30);
                    gIntro = Convert.ToString(mydrv["NewsTitle"]);
                    GridView1.Rows[i].Cells[2].Text = SubStr(gIntro, 10);
                }
            } 

            sqlcon.Close();
        }

        protected void Page_Error(object sender, EventArgs e)
        {
            Exception ex = Server.GetLastError();
            if (HttpContext.Current.Server.GetLastError() is HttpRequestValidationException)
            {
                HttpContext.Current.Response.Write("请输入合法的字符串【<a href=\"javascript:history.back(0);\">返回</a>】");
                HttpContext.Current.Server.ClearError();
            }
        }

        // 变色
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //鼠标经过时，行背景色变 
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#E6F5FA'");
                //鼠标移出时，行背景色变 
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF'");
            }

            // 点击
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // 获取当前鼠标所在行的新闻ID

                // 模板列
                ((HyperLink)e.Row.Cells[0].FindControl("HyperLink1")).NavigateUrl = "/UniversityContestSystem/Page/Con_News/Show/show1.aspx?" + "NewsId=" + Server.UrlEncode(e.Row.Cells[1].Text.Trim());
            }
        }

        // 比较字符串长度
        public string SubStr(string sString, int nLeng)
        {
            if (sString.Length <= nLeng)
            {
                return sString;
            }
            string sNewStr = sString.Substring(0, nLeng);
            sNewStr = sNewStr + "...";
            return sNewStr;
        }
    }
