﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class jiaowei_news_pic : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            string id = Session["ID"].ToString();
            //int id = int.Parse(Context.Request.QueryString["id"]);
            Response.ContentType = "application/binary;";
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
            conn.Open();
            SqlDataReader rd = new SqlCommand("select image from tb_news where NewsID = '" + id + "'", conn).ExecuteReader();
            //byte[] imagebytes = null;
            while (rd.Read())
            {
                //imagebytes = (byte[])rd.GetValue(1);
                this.Response.BinaryWrite((byte[])rd["image"]);
            }
            rd.Close();
            conn.Close();
            //Response.BinaryWrite(imagebytes);
            Response.Flush();
            Response.End();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "')</script>");
        }
    }
}