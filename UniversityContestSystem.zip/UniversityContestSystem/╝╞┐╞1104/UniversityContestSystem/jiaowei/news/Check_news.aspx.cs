﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class jiaowei_news_Check_news : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
           bind();
        try
        {
            string username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
    }
    protected void bind()
    {
         SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
         SqlDataAdapter dap = new SqlDataAdapter("select * from tb_news where IsReviewed is NULL", conn);
         DataTable dt = new DataTable();
         dap.Fill(dt);
         DropDownList1.Items.Clear();
         DropDownList1.DataSource = dt;
         //DropDownList1.DataTextField = "job_desc";
         DropDownList1.DataValueField = "NewsTitle";
         DropDownList1.DataBind();
         if (DropDownList1.Text == "")
         {
             DropDownList1.Visible = false;
             Button1.Visible = false;
             Label1.Visible = true;
         }
         else
         {
             DropDownList1.Visible = true;
             Button1.Visible = true;
             Label1.Visible = false;
         }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        news.Visible = true;
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
        conn.Open();
        SqlDataReader rd = new SqlCommand("select * from tb_news where NewsTitle = '" + DropDownList1.Text + "'", conn).ExecuteReader();
        string id = null;
        while (rd.Read())
        {
            String name = rd["NewsTitle"].ToString();
            String[] s = name.Split(' ');
            name = s[0].ToString();
            title_text.Text = name;
            name = rd["Uploader"].ToString();
            s = name.Split(' ');
            name = s[0].ToString();
            uploader_text.Text = name;

            name = rd["Publicer"].ToString();
            s = name.Split(' ');
            name = s[0].ToString();
            publicer_text.Text= name;

            name = rd["UploadDate"].ToString();
            s = name.Split(' ');
            name = s[0].ToString();
            uploaddate_text.Text = name;

            name = rd["PublicDate"].ToString();
            s = name.Split(' ');
            name = s[0].ToString();
            publicdate_text.Text = name;

            name = rd["News"].ToString();
            s = name.Split(' ');
            name = s[0].ToString();
            news_text.Text= name;
            s = rd["NewsID"].ToString().Split(' ');
            id = s[0].ToString();
            
        }
        Session["ID"] = id;
        conn.Close();
    }

    protected void pass(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
        conn.Open();
        new SqlCommand("update tb_news set (IsReviewed) values ('1') where NewsTitle = '" + DropDownList1.Text + "'", conn).ExecuteReader();
        conn.Close();
        Response.Write("<script>window.location.href ='./Check_news.aspx'<script>");
    }
    protected void failed(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
        conn.Open();
        new SqlCommand("update tb_news set (IsReviewed) values ('0') where NewsTitle = '" + DropDownList1.Text + "'", conn).ExecuteReader();
        conn.Close();
        Response.Write("<script>window.location.href ='./Check_news.aspx'<script>");
    }
}