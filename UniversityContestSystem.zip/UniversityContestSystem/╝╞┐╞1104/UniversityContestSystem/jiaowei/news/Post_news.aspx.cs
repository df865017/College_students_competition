﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
using System.Data;
public partial class jiaowei_news_Post_news : System.Web.UI.Page
{
    SqlConnection sqlcon;
    SqlCommand sqlcom;
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            string username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
    }
    protected void button_Click(object sender, EventArgs e)
    {
        if (title_text.Text != "" || news_text.Text != "" || uploader_text.Text != "" || publicer_text.Text != "")
        {
            try
            {
                //String imgPath = FileUpload1.PostedFile.FileName;
                //string str = "insert into tb_news(NewsTitle,News,Uploader,Publicer,UploadDate,PublicDate,IsReviewed,IsPubliced,imageurl)";
                string str = "insert into tb_news(NewsTitle,News,Uploader,Publicer,UploadDate,PublicDate,IsReviewed,IsPubliced,Image)";
                string sqlstr = str + " values('" + title_text.Text + "','" + news_text.Text + "','" + uploader_text.Text + "','" + publicer_text.Text + "','" + DateTime.Now + "','" + DateTime.Now + "','1','1',@imagedata)";
                sqlcon = new SqlConnection(strCon);
                sqlcon.Open();
                sqlcom = new SqlCommand(sqlstr, sqlcon);

                String imgPath = FileUpload1.PostedFile.FileName;
                String imgName = imgPath.Substring(imgPath.LastIndexOf("\\") + 1);
                String imgExtend = imgPath.Substring(imgPath.LastIndexOf(".") + 1);
                int FileLen = this.FileUpload1.PostedFile.ContentLength;
                Byte[] FileData = new Byte[FileLen];
                HttpPostedFile hp = FileUpload1.PostedFile;
                Stream sr = hp.InputStream;
                sr.Read(FileData, 0, FileLen);
                sqlcom.Parameters.Add("@imagedata", SqlDbType.Image);
                sqlcom.Parameters["@imagedata"].Value = FileData; /* */
                sqlcom.ExecuteNonQuery();



                sqlcon.Close();
                //sqlcom.ExecuteReader();
                Response.Write("<script>alert('发布成功！');window.location.href ='./Post_news.aspx' </script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
        }
        else Response.Write("<script>alert('请输入完整信息！')</script>");
        
    }
    protected void button1_Click(object sender, EventArgs e)
    {
        title_text.Text = "";
        news_text.Text = "";
        uploader_text.Text = "";
        publicer_text.Text = "";
    }
}