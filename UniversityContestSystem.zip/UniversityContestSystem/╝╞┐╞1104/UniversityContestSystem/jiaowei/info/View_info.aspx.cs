﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class jiaowei_info_View_info : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {        
        String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        string username = null;
        try
        {
            username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
        SqlCommand cmd = new SqlCommand("select * from tb_admin where adName='"+username+"'" , conn);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            String name = rd["adName"].ToString();
            String[] s = name.Split(' ');
            name = s[0].ToString();
            Label2.Text = name;
            String email = rd["aEmail"].ToString();
            s = email.Split(' ');
            email = s[0].ToString();
            Label4.Text = email;
            String sex = rd["aSex"].ToString();
            s = sex.Split(' ');
            sex = s[0].ToString();
            Label6.Text = sex;
            String age = rd["age"].ToString();
            s = age.Split(' ');
            age = s[0].ToString();
            Label8.Text = age;
        }
        conn.Close();
    }
}