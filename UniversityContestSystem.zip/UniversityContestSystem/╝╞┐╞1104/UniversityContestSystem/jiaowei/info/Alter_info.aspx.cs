﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class jiaowei_info_Alter_info : System.Web.UI.Page
{   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();
            string username = null;
            try
            {
                username = Session["userName"].ToString();
            }
            catch (Exception ex)
            {
                Response.Write("<script>location.href='../Page/home.aspx';</script>");
            }
            SqlCommand cmd = new SqlCommand("select * from tb_admin where adName='"+username+"'", conn);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                String name = rd["adName"].ToString();
                String[] s = name.Split(' ');
                name = s[0].ToString();
                TextBox1.Text = name;
                String email = rd["aEmail"].ToString();
                s = email.Split(' ');
                email = s[0].ToString();
                TextBox4.Text = email;
                String sex = rd["aSex"].ToString();
                s = sex.Split(' ');
                sex = s[0].ToString();
                if (sex == "男") RadioButton1.Checked = true;
                else RadioButton2.Checked = true;
                String age = rd["age"].ToString();
                s = age.Split(' ');
                age = s[0].ToString();
                TextBox3.Text = age;
            }
            conn.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        string username = null;
        try
        {
            username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
        SqlCommand cmd = new SqlCommand("select * from tb_admin where adName='" + username + "'", conn);
        SqlDataReader rd = cmd.ExecuteReader();
        string psw = null;
        while (rd.Read())
        {
            psw = rd["password"].ToString();
            String[] s = psw.Split(' ');
            psw = s[0].ToString();
             
        }
        conn.Close();
        
        if (psw == TextBox5.Text)
        {            
            conn.Open();            
            string name = TextBox1.Text;
            string sex = null;
            if (RadioButton1.Checked == true) sex = "男";
            else if(RadioButton2.Checked==true) sex = "女";
            string email = TextBox4.Text;
            int age = int.Parse(TextBox3.Text);
            String sqlstr = "update tb_admin set adName='" + name + "',aEmail='" + email + "', aSex='" + sex + "',age='" + age + "' where adName='" + username + "' ";
            new SqlCommand(sqlstr, conn).ExecuteReader();
            Session["userName"] = name;
            Response.Write("<script>alert('修改成功！')</script>");           
            conn.Close();
        }
        else Response.Write("<script>alert('密码错误！')</script>");        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        string username = null;
        try
        {
            username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
        SqlCommand cmd = new SqlCommand("select * from tb_admin where adName='" +username + "'", conn);
        SqlDataReader rd = cmd.ExecuteReader();
        string psw = null;
        while (rd.Read())
        {
            psw = rd["password"].ToString();
            String[] s = psw.Split(' ');
            psw = s[0].ToString();

        }
        conn.Close();
        if (TextBox6.Text == "" || TextBox7.Text == "" || TextBox8.Text == "")
        {
            TextBox6.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
            Response.Write("<script>alert('请输入完整信息！')</script>");
        }
        else if (psw == TextBox6.Text)
        {
            if (TextBox7.Text == TextBox8.Text)
            {
                conn.Open();
                String sqlstr = "update tb_admin set password='" + TextBox7.Text + "' where adName='" + username + "' ";
                new SqlCommand(sqlstr, conn).ExecuteReader();
                Response.Write("<script>alert('修改成功！')</script>");
                conn.Close();
            }
            else Response.Write("<script>alert('两次输入不一致！')</script>");
        }
        else Response.Write("<script>alert('密码错误！')</script>");
    }
}