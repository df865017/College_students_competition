﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Globalization;
public partial class jiaowei_con_man_Add_con : System.Web.UI.Page
{
    SqlConnection sqlcon;
    SqlCommand sqlcom;
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            string username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
    }
    protected void ImageButton_Click(object sender, EventArgs eventArgs)  
       {           
           calendar.Visible = !calendar.Visible;  
       }
    
    protected void RequestedDeliveryDateCalendar_SelectionChanged(object sender, EventArgs eventArgs)
    {
        TextBox2.Text = requestedDeliveryDateCalendar.SelectedDate.ToShortDateString();       
        calendar.Visible = false;  
        TextBox3.Focus();
    }
    protected void ImageButton2_Click(object sender, EventArgs eventArgs)
    {
        Div1.Visible = !Div1.Visible;
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs eventArgs)
    {
        TextBox3.Text = Calendar1.SelectedDate.ToShortDateString();
        Div1.Visible = false;
        TextBox4.Focus();
    }
    protected void ImageButton3_Click(object sender, EventArgs eventArgs)
    {
        Div2.Visible = !Div2.Visible;
    }

    protected void Calendar2_SelectionChanged(object sender, EventArgs eventArgs)
    {
        TextBox4.Text = Calendar2.SelectedDate.ToShortDateString();
        Div2.Visible = false;
        TextBox5.Focus();
    }
    protected void ImageButton4_Click(object sender, EventArgs eventArgs)
    {
        Div3.Visible = !Div3.Visible;
    }

    protected void Calendar3_SelectionChanged(object sender, EventArgs eventArgs)
    {
        TextBox5.Text = Calendar3.SelectedDate.ToShortDateString();
        Div3.Visible = false;
        DropDownList2.Focus();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            string conname = TextBox1.Text;

            DateTimeFormatInfo dtFormat = new System.Globalization.DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "rrrr/MM/dd";

            System.DateTime startsign = Convert.ToDateTime(TextBox2.Text, dtFormat);
            System.DateTime endsign = Convert.ToDateTime(TextBox3.Text, dtFormat);
            System.DateTime start = Convert.ToDateTime(TextBox4.Text, dtFormat);
            System.DateTime end = Convert.ToDateTime(TextBox5.Text, dtFormat);
            string conkid = DropDownList3.Text;
            string schoolname = DropDownList2.Text;
            string conlei = DropDownList1.Text;

            //查询得到学校的ID
            string sid = null; int sID = 0;
            string sqlstr = "select sId from tb_school where schoolName='" + schoolname + "'";
            sqlcon = new SqlConnection(strCon);
            sqlcon.Open();
            SqlDataReader rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            while (rd.Read())
            {
                sid = rd["sId"].ToString();
                String[] s = sid.Split(' ');
                sid = s[0].ToString();
                sID = int.Parse(sid);
            }

            sqlcon.Close();

            //查询得到竞赛类别ID
            string conleiid = null; int conleiID = 0;
            sqlstr = "select leiId from tb_contestlei where leiName='" + conlei + "'";
            sqlcon.Open();
            rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            while (rd.Read())
            {
                conleiid = rd["leiId"].ToString();
                String[] s = conleiid.Split(' ');
                conleiid = s[0].ToString();
                conleiID = int.Parse(conleiid);
            }

            sqlcon.Close();

            //将信息添加到数据库
            sqlstr = "insert into tb_contest(conName,startSign,endSign,start,[end],conkind,schoolId,contestKind) values ('" + conname + "','" + startsign + "','" + endsign + "','" + start + "','" + end + "','" + conleiID + "','" + sID + "','" + conkid + "')";
            sqlcon.Open();
            new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            sqlcon.Close();
            Response.Write("<script>alert('添加成功！');window.location.href ='./Add_con.aspx'   </script>");
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('"+ex.Message+"');window.location.href ='./Add_con.aspx'   </script>");
        }
    }

    protected void calendar_DayRender(object sender, DayRenderEventArgs e)
    {//每次加载一个日期都会触发这个事件
        if (e.Day.Date < System.DateTime.Now)
        {
            e.Day.IsSelectable = false;
            //e.Cell.Font.Strikeout = true;
        }
        if (e.Day.Date == DateTime.Now.Date)
        {
            e.Day.IsSelectable = true;
            e.Cell.BackColor = System.Drawing.Color.Yellow;
        }
    }
}