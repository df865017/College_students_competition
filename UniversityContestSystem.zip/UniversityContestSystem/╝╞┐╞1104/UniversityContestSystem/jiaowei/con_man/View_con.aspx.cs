﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
public partial class jiaowei_con_man_View_con : System.Web.UI.Page
{
    SqlConnection sqlcon;
    SqlCommand sqlcom;
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
            Label2.Visible = Label3.Visible = Label4.Visible = Label5.Visible = Label6.Visible = false;
            Label7.Visible = Label8.Visible = Label9.Visible = Label10.Visible = Label11.Visible = false;
            Label12.Visible = Label13.Visible = Label14.Visible = Label15.Visible = Label16.Visible = false;
            Label17.Visible = Label18.Visible = Label19.Visible = false;
            TextBox1.Visible = TextBox2.Visible = TextBox3.Visible = TextBox4.Visible = false;
            TextBox5.Visible = TextBox6.Visible = false;
            DropDownList2.Visible = DropDownList3.Visible = false;
            Button2.Visible = Button3.Visible = Button4.Visible = false;
            Button3.Enabled = Button4.Enabled = false;
        }
        try
        {
            string username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
    }

    protected void bind()
    {
        try
        {
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
            SqlDataAdapter dap = new SqlDataAdapter("select conName from tb_contest", conn);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            DropDownList1.Items.Clear();
            DropDownList1.DataSource = dt;
            DropDownList1.DataValueField = "conName";
            DropDownList1.DataBind();
            if (DropDownList1.Text == "")
            {
                DropDownList1.Visible = false;
                Button1.Visible = false;
                Label20.Visible = true;
                Label1.Visible = false;
            }
            else
            {
                DropDownList1.Visible = true;
                Button1.Visible = true;
                Label1.Visible = false;
                Label20.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "');</script>");
        }        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox1.Visible = TextBox2.Visible = TextBox3.Visible = TextBox4.Visible = false;
        TextBox5.Visible = TextBox6.Visible = false;
        DropDownList2.Visible = DropDownList3.Visible = false;
        Button3.Enabled = Button4.Enabled = false;
        Label2.Visible = Label3.Visible = Label4.Visible = Label5.Visible = Label6.Visible = true;
        Label7.Visible = Label8.Visible = Label9.Visible = Label10.Visible = Label11.Visible = true;
        Label12.Visible = Label13.Visible = Label14.Visible = Label15.Visible = Label16.Visible = true;
        Label17.Visible = Label18.Visible = Label19.Visible = true;
        Button2.Visible = Button3.Visible = Button4.Visible = true;
        Button2.Enabled = true;

        try
        {
            string sqls = "select conName,startSign,endSign,start,[end],contestKind,tb_school.schoolName [schoolname],tb_contestlei.leiName [conleiname] from tb_contest,tb_contestlei,tb_school";
            string sqlstr = sqls + " where tb_contest.schoolId=tb_school.sId and tb_contest.conKind=tb_contestlei.leiId and conName='" + DropDownList1.Text + "'";
            sqlcon = new SqlConnection(strCon);
            sqlcon.Open();
            SqlDataReader rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            while (rd.Read())
            {
                string sn = rd["conName"].ToString();
                String[] s = sn.Split(' ');
                sn = s[0].ToString();
                Label3.Text = TextBox1.Text = sn;

                sn = rd["schoolname"].ToString();
                s = sn.Split(' ');
                sn = s[0].ToString();
                Label5.Text = DropDownList2.Text = sn;

                sn = rd["conleiName"].ToString();
                s = sn.Split(' ');
                sn = s[0].ToString();
                Label7.Text = DropDownList3.Text = sn;

                sn = rd["startSign"].ToString();
                s = sn.Split(' ');
                sn = s[0].ToString();
                Label10.Text = TextBox2.Text = sn;

                sn = rd["endSign"].ToString();
                s = sn.Split(' ');
                sn = s[0].ToString();
                Label12.Text = TextBox3.Text = sn;

                sn = rd["start"].ToString();
                s = sn.Split(' ');
                sn = s[0].ToString();
                Label15.Text = TextBox4.Text = sn;

                sn = rd["end"].ToString();
                s = sn.Split(' ');
                sn = s[0].ToString();
                Label17.Text = TextBox5.Text = sn;

                sn = rd["contestKind"].ToString();
                s = sn.Split(' ');
                sn = s[0].ToString();
                Label19.Text = TextBox6.Text = sn;
            }
            sqlcon.Close();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "');</script>");
        }
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Label3.Visible = Label5.Visible = Label7.Visible = Label10.Visible = false;
        Label12.Visible = Label15.Visible = Label17.Visible = Label19.Visible = false;
        TextBox1.Visible = TextBox2.Visible = TextBox3.Visible = TextBox4.Visible = true;
        TextBox5.Visible = TextBox6.Visible = true;
        DropDownList2.Visible = DropDownList3.Visible = true;
        Button2.Enabled = false;
        Button3.Enabled = Button4.Enabled = true;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        try
        {
            DateTimeFormatInfo dtFormat = new System.Globalization.DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "rrrr/MM/dd";

            string schoolname = DropDownList2.Text;
            string conlei = DropDownList3.Text;

            //查询得到学校的ID
            string sid = null; int sID = 0;
            string sqlstr = "select sId from tb_school where schoolName='" + schoolname + "'";
            sqlcon = new SqlConnection(strCon);
            sqlcon.Open();
            SqlDataReader rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            while (rd.Read())
            {
                sid = rd["sId"].ToString();
                String[] s = sid.Split(' ');
                sid = s[0].ToString();
                sID = int.Parse(sid);
            }

            sqlcon.Close();

            //查询得到竞赛类别ID
            string conleiid = null; int conleiID = 0;
            sqlstr = "select leiId from tb_contestlei where leiName='" + conlei + "'";
            sqlcon.Open();
            rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            while (rd.Read())
            {
                conleiid = rd["leiId"].ToString();
                String[] s = conleiid.Split(' ');
                conleiid = s[0].ToString();
                conleiID = int.Parse(conleiid);
            }

            sqlcon.Close();

            System.DateTime startsign = Convert.ToDateTime(TextBox2.Text, dtFormat);
            System.DateTime endsign = Convert.ToDateTime(TextBox3.Text, dtFormat);
            System.DateTime start = Convert.ToDateTime(TextBox4.Text, dtFormat);
            System.DateTime end = Convert.ToDateTime(TextBox5.Text, dtFormat);
            sqlstr = "update tb_contest set conName='" + TextBox1.Text + "',startSign='" + startsign + "',endSign='" + endsign + "'," +
            "start='" + start + "',[end]='" + end + "',conKind='" + conleiID + "',schoolId='" + sID + "',contestKind='" + TextBox6.Text + "' where conName='" + DropDownList1.Text + "'";

            sqlcon.Open();
            new SqlCommand(sqlstr, sqlcon).ExecuteReader();
            Response.Write("<script>alert('修改成功！');window.location.href ='./View_con.aspx'   </script>");
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "');</script>");
        }
        
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Label3.Visible = Label5.Visible = Label7.Visible = Label10.Visible = true;
        Label12.Visible = Label15.Visible = Label17.Visible = Label19.Visible = true;
        TextBox1.Visible = TextBox2.Visible = TextBox3.Visible = TextBox4.Visible = false;
        TextBox5.Visible = TextBox6.Visible = false;
        DropDownList2.Visible = DropDownList3.Visible = false;
        Button2.Enabled = true;
        Button3.Enabled = Button4.Enabled = false;
    }
}