﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class jiaowei_con_man_Con_lei_man : System.Web.UI.Page
{
    SqlConnection sqlcon;
    SqlCommand sqlcom;
    string strCon = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        bind();
        Label2.Visible = false;
        try
        {
            string username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text != "")
        {
            try
            {
                string sqlstr = "select * from tb_contestlei where leiName='" + TextBox1.Text + "'";
                sqlcon = new SqlConnection(strCon);
                sqlcon.Open();
                SqlDataReader rd = new SqlCommand(sqlstr, sqlcon).ExecuteReader();
                if (rd.Read())
                {
                    Label2.Visible = true;
                }
                else
                {
                    sqlcon.Close();
                    sqlstr = "insert into tb_contestlei (leiName) values('" + TextBox1.Text + "')";
                    //Response.Write("<script>alert('"+name+"')</script>");
                    sqlcon = new SqlConnection(strCon);
                    sqlcon.Open();
                    new SqlCommand(sqlstr, sqlcon).ExecuteNonQuery();
                    sqlcon.Close();
                    TextBox1.Text = "";
                    bind();
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }            
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            string name = GridView1.DataKeys[e.RowIndex].Value.ToString();
            string sqlstr = "delete from tb_contestlei where leiId='" + name + "'";
            //Response.Write("<script>alert('"+name+"')</script>");
            sqlcon = new SqlConnection(strCon);
            sqlcon.Open();
            new SqlCommand(sqlstr, sqlcon).ExecuteNonQuery();
            sqlcon.Close();
            bind();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "');</script>");
        }
        
    }
    public void bind()
    {
        try
        {
            string sqlstr = "select leiId as '序号',leiName as '类名' from tb_contestlei";
            sqlcon = new SqlConnection(strCon);
            SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
            DataSet myds = new DataSet();
            sqlcon.Open();
            myda.Fill(myds, "tb_contestlei");
            GridView1.DataSource = myds;
            GridView1.DataKeyNames = new string[] { "序号" };//主键
            GridView1.DataBind();
            sqlcon.Close();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "');</script>");
        }       
    }
    protected void PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
        DataBind();//重新绑定一遍数据
    }    
}