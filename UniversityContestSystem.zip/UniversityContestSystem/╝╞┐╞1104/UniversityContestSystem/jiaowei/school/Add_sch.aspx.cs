﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class jiaowei_school_Add_sch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label4.Visible = Label5.Visible = Label6.Visible = false;
        if (!IsPostBack)
        {
            TextBox1.Text = TextBox2.Text = TextBox3.Text = "";
        }
        try
        {
            string username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        bool right = true;
        string schoolname = TextBox1.Text;
        string schConName = TextBox2.Text;
        string email = TextBox3.Text;
        String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        string cmdstr = "select * from tb_school where schoolName='"+schoolname+"'";
        SqlDataReader rd= new SqlCommand(cmdstr, conn).ExecuteReader();
        if (rd.Read())
        {
            Label4.Visible = true; right = false; ;
        }
        conn.Close();
        conn.Open();
        cmdstr = "select * from tb_school where schConName='" + schConName + "'";
        SqlDataReader rd1 = new SqlCommand(cmdstr, conn).ExecuteReader();
        if (rd1.Read())
        {
            Label5.Visible = true; right = false;
        }
        conn.Close();
        conn.Open();
        cmdstr = "select * from tb_school where mail='" + email + "'";
        SqlDataReader rd2 = new SqlCommand(cmdstr, conn).ExecuteReader();
        if (rd2.Read())
        {
            Label6.Visible = true; right = false;
        }
        conn.Close();
        if (right == true)
        {
            cmdstr = "insert into tb_school(schConName,schoolName,mail,password) values ('" + TextBox2.Text + "','" + TextBox1.Text + "','" + TextBox3.Text + "','000000')";
            conn.Open();
            new SqlCommand(cmdstr, conn).ExecuteReader();
            Response.Write("<script>alert('添加成功！');window.location.href ='./Add_sch.aspx'   </script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = TextBox2.Text = TextBox3.Text = "";
        Label4.Visible = Label5.Visible = Label6.Visible = false;

    }
}