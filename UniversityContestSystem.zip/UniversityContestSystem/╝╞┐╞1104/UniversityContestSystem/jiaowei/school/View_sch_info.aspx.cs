﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class jiaowei_school_View_sch_info : System.Web.UI.Page
{    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();            
            Label1.Visible = false;
            Label2.Visible = false;
            Label3.Visible = false;
            Label4.Visible = false;
            Label6.Visible = false;
            Label5.Visible = false;
            TextBox1.Visible = false;
            TextBox2.Visible = false;
            TextBox3.Visible = false;
            Button2.Visible = false;
            Button3.Visible = false;
            Button4.Visible = false;                
            Button5.Visible = false;
            key.Visible = key1.Visible = false;
        }
        try
        {
            string username = Session["userName"].ToString();
        }
        catch (Exception ex)
        {
            Response.Write("<script>location.href='../Page/home.aspx';</script>");
        }
    }

    protected void bind()
    {
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=true");
        SqlDataAdapter dap = new SqlDataAdapter("select schoolName from tb_school", conn);
        DataTable dt = new DataTable();
        dap.Fill(dt);
        DropDownList1.Items.Clear();
        DropDownList1.DataSource = dt;
        DropDownList1.DataValueField = "schoolName";
        DropDownList1.DataBind();
        if (DropDownList1.Text == "")
        {
            DropDownList1.Visible = false;
            Button1.Visible = false;
            Label7.Visible = true;
            Sch_cho.Visible = false;
        }
        else
        {
            DropDownList1.Visible = true;
            Button1.Visible = true;
            Label1.Visible = false;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Button5.Visible = true;
        info.Visible = true;
        Label1.Visible = true;
        Label2.Visible = true;
        Label3.Visible = true;
        Label4.Visible = true;
        Label5.Visible = true;
        Label6.Visible = true;
        TextBox1.Visible = false;
        TextBox2.Visible = false;
        TextBox3.Visible = false;
        Button2.Visible = true;
        Button3.Visible = true; Button3.Enabled = false;
        Button4.Visible = true; Button4.Enabled = false;
        key.Visible = key1.Visible = false;

        string school_name = DropDownList1.Text;
        String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        SqlCommand cmd = new SqlCommand("select * from tb_school where schoolName='"+school_name+"'", conn);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            String name = rd["schoolName"].ToString();
            String[] s = name.Split(' ');
            name = s[0].ToString();
            Label4.Text = name;
            String email = rd["mail"].ToString();
            s = email.Split(' ');
            email = s[0].ToString();
            Label6.Text = email;
            String con = rd["schConName"].ToString();
            s = con.Split(' ');
            con = s[0].ToString();
            Label5.Text = con;           
        }
        conn.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Button2.Enabled = false; Button3.Enabled = true; Button4.Enabled = true;       
        Label4.Visible = false;
        Label5.Visible = false;
        Label6.Visible = false;
        TextBox1.Visible = true;
        TextBox2.Visible = true;
        TextBox3.Visible = true;
        string school_name = DropDownList1.Text;
        String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        SqlCommand cmd = new SqlCommand("select * from tb_school where schoolName='" + school_name + "'", conn);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            String name = rd["schoolName"].ToString();
            String[] s = name.Split(' ');
            name = s[0].ToString();
            TextBox1.Text = name;
            String email = rd["mail"].ToString();
            s = email.Split(' ');
            email = s[0].ToString();
            TextBox3.Text = email;
            String con = rd["schConName"].ToString();
            s = con.Split(' ');
            con = s[0].ToString();
            TextBox2.Text = con;
        }
        conn.Close();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Label1.Visible = true;
        Label2.Visible = true;
        Label3.Visible = true;
        Label4.Visible = true;
        Label5.Visible = true;
        Label6.Visible = true;
        TextBox1.Visible = false;
        TextBox2.Visible = false;
        TextBox3.Visible = false;
        Button2.Enabled = true;
        Button3.Enabled = Button4.Enabled = false;
        string school_name = DropDownList1.Text;
        String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        SqlCommand cmd = new SqlCommand("select * from tb_school where schoolName='" + school_name + "'", conn);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            String name = rd["schoolName"].ToString();
            String[] s = name.Split(' ');
            name = s[0].ToString();
            Label4.Text = name;
            String email = rd["mail"].ToString();
            s = email.Split(' ');
            email = s[0].ToString();
            Label6.Text = email;
            String con = rd["schConName"].ToString();
            s = con.Split(' ');
            con = s[0].ToString();
            Label5.Text = con;
        }
        conn.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Button3.Enabled = Button4.Enabled = false;
        Button2.Enabled = true;
        Label4.Visible = Label5.Visible = Label6.Visible = true;
        TextBox1.Visible = TextBox2.Visible = TextBox3.Visible = false;        
        
        String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
        SqlConnection conn = new SqlConnection(strconn);
        conn.Open();
        string cmdstr = "update tb_school set schConName='"+TextBox2.Text+"',schoolName='"+TextBox1.Text+"',mail='"+TextBox3.Text+"' where schoolName='"+DropDownList1.Text+"'";        
        new SqlCommand(cmdstr, conn).ExecuteReader();
        conn.Close();

        conn.Open();
        cmdstr = "select * from tb_school where schoolName='"+DropDownList1.Text+"'";

        SqlDataReader rd = new SqlCommand(cmdstr, conn).ExecuteReader();
        while (rd.Read())
        {
            String name = rd["schoolName"].ToString();
            String[] s = name.Split(' ');
            name = s[0].ToString();
            Label4.Text = name;
            String email = rd["mail"].ToString();
            s = email.Split(' ');
            email = s[0].ToString();
            Label6.Text = email;
            String con = rd["schConName"].ToString();
            s = con.Split(' ');
            con = s[0].ToString();
            Label5.Text = con;
        }
        conn.Close();
    }

    protected void Button5_Click(object sender, EventArgs e)
    {       
        info.Visible = false;
        key.Visible = key1.Visible = true;
        inputkey.Focus();
    }
    protected void submit_click(object sender, EventArgs e)
    {
        if (inputkey.Text != "" || inputkey2.Text != "")
        {
            String strconn = "Data Source=.;Initial Catalog=SoftwareProject;Integrated Security=True";
            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();
            string username = null;
            try
            {
                username = Session["userName"].ToString();
            }
            catch (Exception ex)
            {
                Response.Write("<script>location.href='../Page/home.aspx';</script>");
            }
            SqlCommand cmd = new SqlCommand("select * from tb_admin where adName='"+username+"'", conn);
            SqlDataReader rd = cmd.ExecuteReader();
            string psw = null;
            while (rd.Read())
            {
                psw = rd["password"].ToString();
                String[] s = psw.Split(' ');
                psw = s[0].ToString();

            }
            conn.Close();
            if (psw == inputkey.Text)
            {
                if (inputkey.Text == inputkey2.Text)
                {
                    conn.Open();
                    String sqlstr = "update tb_school set password='000000' where schoolName ='" + DropDownList1.Text + "' ";
                    new SqlCommand(sqlstr, conn).ExecuteReader();
                    Response.Write("<script>alert('初始化成功！'); window.location.href ='./View_sch_info.aspx' </script>");
                    conn.Close();
                }
                else { inputkey.Focus(); Response.Write("<script>alert('两次输入不一致！')</script>"); }
            }
            else { inputkey.Focus(); Response.Write("<script>alert('密码错误！')</script>"); }
        }
        else
        {
            inputkey.Text = "";
            inputkey2.Text = "";
            inputkey.Focus();
            Response.Write("<script>alert('请输入完整信息！')</script>");
        }
    }
}